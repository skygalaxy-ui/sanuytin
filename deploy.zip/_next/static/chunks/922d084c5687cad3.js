(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,87316,e=>{"use strict";let t=(0,e.i(75254).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);e.s(["Calendar",()=>t],87316)},72520,e=>{"use strict";let t=(0,e.i(75254).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);e.s(["ArrowRight",()=>t],72520)},55900,e=>{"use strict";let t=(0,e.i(75254).default)("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);e.s(["ChevronUp",()=>t],55900)},63059,e=>{"use strict";let t=(0,e.i(75254).default)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);e.s(["ChevronRight",()=>t],63059)},3116,e=>{"use strict";let t=(0,e.i(75254).default)("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);e.s(["Clock",()=>t],3116)},83086,e=>{"use strict";let t=(0,e.i(75254).default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]);e.s(["Sparkles",()=>t],83086)},42942,e=>{"use strict";let t=[{id:1,rank:1,name:"Vantage",slug:"vantage",logo:"https://sanuytin.net/wp-content/uploads/2025/11/san-giao-dich-forex-vantage-co-uy-tin-khong.png",score:9.9,minDep:"$50",maxLev:"1:1000",license:"ASIC, FCA, CIMA",features:["Khớp lệnh siêu tốc","Raw Spread từ 0.0","Hỗ trợ người Việt"],reviewLink:"vantage",registerLink:"https://www.vantage-markets-apac.com/vi/open-live-account/?affid=NzI2ODQyNw==",foundedYear:"2009",headquarters:"Sydney, Australia",platforms:["MT4","MT5","ProTrader","App"],depositMethods:["Internet Banking","Visa/Master","USDT","Skrill"],pros:["Được cấp phép bởi các tổ chức uy tín hàng đầu (ASIC, FCA)","Tốc độ khớp lệnh cực nhanh, không re-quote","Phí giao dịch thấp, đặc biệt là tài khoản Raw ECN","Hỗ trợ nạp rút tiền nhanh chóng qua ngân hàng nội địa"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Yêu cầu tiền nạp tối thiểu $50 (cao hơn một số sàn khác)","Ít chương trình Bonus cho khách hàng cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Vantage
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Vantage</strong> (trước đ\xe2y l\xe0 Vantage FX) l\xe0 nh\xe0 m\xf4i giới đa t\xe0i sản to\xe0n cầu được th\xe0nh lập từ năm 2009, c\xf3 trụ sở ch\xednh tại Sydney, \xdac. 
                        Với hơn 15 năm hoạt động, Vantage đ\xe3 khẳng định vị thế l\xe0 "Thi\xean đường cho ECN Trader" nhờ hạ tầng c\xf4ng nghệ vượt trội.
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        S\xe0n kết nối trực tiếp với c\xe1c nh\xe0 cung cấp thanh khoản h\xe0ng đầu (Tier-1 Liquidity Providers) qua cầu nối quang học <span class="font-semibold text-foreground">oneZero™ MT4 Bridge</span>, 
                        đảm bảo tốc độ khớp lệnh si\xeau tốc (dưới 30ms) v\xe0 kh\xf4ng c\xf3 sự can thiệp của b\xe0n giao dịch (No Dealing Desk).
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p & Độ Uy T\xedn
                    </h3>
                    <p class="mb-3 text-muted-foreground">Vantage sở hữu hồ sơ ph\xe1p l\xfd cực kỳ "sạch" v\xe0 uy t\xedn với c\xe1c giấy ph\xe9p hạng A:</p>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">ASIC (\xdac)</span>
                            <span class="text-sm text-muted-foreground">GP số 428901 - Một trong những giấy ph\xe9p kh\xf3 đạt được nhất thế giới.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">FCA (Anh)</span>
                            <span class="text-sm text-muted-foreground">GP số 590299 - Bảo hiểm tiền gửi l\xean đến \xa385,000 cho kh\xe1ch h\xe0ng.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">CIMA (Cayman)</span>
                            <span class="text-sm text-muted-foreground">GP số 1383491 - Quản l\xfd hoạt động to\xe0n cầu với cơ chế linh hoạt.</span>
                        </li>
                    </ul>
                    <p class="text-sm text-muted-foreground italic">
                        *Tiền k\xfd quỹ của kh\xe1ch h\xe0ng được giữ trong t\xe0i khoản t\xe1ch biệt (Segregated Accounts) tại Ng\xe2n h\xe0ng Quốc gia \xdac (NAB), đảm bảo an to\xe0n tuyệt đối.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Điều Kiện Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Loại T\xe0i Khoản</th>
                                    <th class="p-3 text-left">Spread Từ</th>
                                    <th class="p-3 text-left">Hoa Hồng (2 chiều)</th>
                                    <th class="p-3 text-left">Nạp Tối Thiểu</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Standard STP</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-green-600">Kh\xf4ng ph\xed</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr class="bg-primary/5">
                                    <td class="p-3 font-medium">Raw ECN (Khuy\xean d\xf9ng)</td>
                                    <td class="p-3 font-bold text-primary">0.0 pips</td>
                                    <td class="p-3">$6.0</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Pro ECN</td>
                                    <td class="p-3">0.0 pips</td>
                                    <td class="p-3">$3.0</td>
                                    <td class="p-3">$10,000</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="mt-3 text-muted-foreground">
                        Với t\xe0i khoản <strong>Raw ECN</strong>, bạn sẽ được trải nghiệm spread V\xe0ng gần như bằng 0 trong phi\xean \xc2u v\xe0 Mỹ. Đ\xe2y l\xe0 điểm mạnh tuyệt đối của Vantage so với Exness hay XM.
                    </p>
                </div>
            </div>
        `},{id:3,rank:2,name:"XM",slug:"xm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xm-sanuytin.jpg",score:9.8,minDep:"$5",maxLev:"1:1000",license:"ASIC, CySEC, FSC",features:["Bonus $30 không cần nạp","Phí qua đêm thấp","Khớp lệnh nhanh"],reviewLink:"xm",registerLink:"https://affs.click/mG65j",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","XM App"],depositMethods:["Internet Banking","MoMo","Visa"],pros:["Chương trình Bonus thưởng nạp tiền hấp dẫn nhất","Không yêu cầu báo giá lại (Re-quotes)","Phí spread ổn định, không giãn mạnh"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Tài khoản Standard có spread hơi cao so với ECN","Giao diện web hơi cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tại Sao XM Được Y\xeau Th\xedch?
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>XM</strong> (XM Global) l\xe0 một trong những nh\xe0 m\xf4i giới lớn nhất thế giới với hơn <strong>10 triệu kh\xe1ch h\xe0ng</strong> từ 190 quốc gia. 
                        Thương hiệu XM gắn liền với sự "H\xe0o Ph\xf3ng" nhờ c\xe1c chương tr\xecnh khuyến m\xe3i khủng v\xe0 ch\xednh s\xe1ch kh\xf4ng b\xe1o gi\xe1 lại (No Re-quotes).
                    </p>
                    <div class="bg-card p-4 rounded-xl border border-border shadow-sm flex gap-4 items-center">
                        <div class="bg-green-500/10 p-3 rounded-full text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        </div>
                        <div>
                            <div class="font-bold text-foreground">Bonus $30 (Kh\xf4ng Cần Nạp)</div>
                            <div class="text-sm text-muted-foreground">Tặng ngay $30 v\xe0o t\xe0i khoản khi mở mới. L\xe3i r\xfat được, tiền thưởng kh\xf4ng r\xfat được.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> T\xe0i Khoản Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Đặc Điểm</th>
                                    <th class="p-3 text-left">Micro</th>
                                    <th class="p-3 text-left">Standard</th>
                                    <th class="p-3 text-left">Ultra Low</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Tiền nạp tối thiểu</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Spread từ</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-primary">0.6 pips</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Hoa hồng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Lot size</td>
                                    <td class="p-3">1,000 unit</td>
                                    <td class="p-3">100,000 unit</td>
                                    <td class="p-3">Chuẩn</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Ưu Đ\xe3i Độc Quyền
                    </h3>
                    <ul class="space-y-2">
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Thưởng nạp tiền 50% l\xean đến $500 v\xe0 20% l\xean đến $4,500.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Chương tr\xecnh kh\xe1ch h\xe0ng th\xe2n thiết (XM Loyalty) t\xedch điểm đổi tiền mặt.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Miễn ph\xed m\xe1y chủ ảo (VPS) cho t\xe0i khoản c\xf3 số dư > $500.</span>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:2,rank:3,name:"Exness",slug:"exness",logo:"https://sanuytin.net/wp-content/uploads/2025/10/exness-sanuytin.jpg",score:9.5,minDep:"$10",maxLev:"Vô cực",license:"FCA, CySEC, FSA",features:["Nạp rút tức thì","Spread cực thấp","Hỗ trợ tiếng Việt 24/7"],reviewLink:"exness",registerLink:"#",foundedYear:"2008",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","Exness Terminal"],depositMethods:["Internet Banking","VietQR","USDT","Visa/Master"],pros:["Nạp rút tiền diễn ra tức thì, kể cả cuối tuần","Đòn bẩy không giới hạn (Vô cực)","Spread trên cặp vàng và tiền tệ chính cực thấp","Đội ngũ hỗ trợ người Việt 24/7 nhiệt tình"],avgSpread:"0.6 pips",commission:"Không phí",cons:["Máy chủ đôi khi bị lag vào giờ tin mạnh","Spread có thể giãn nhẹ khi thị trường biến động cực đoan"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Exness
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Exness</strong> được cộng đồng trader Việt Nam mệnh danh l\xe0 "Vua thanh khoản". Th\xe0nh lập từ 2008, Exness hiện l\xe0 nh\xe0 m\xf4i giới c\xf3 khối lượng giao dịch lớn nhất thế giới (đạt hơn 4.000 tỷ USD/th\xe1ng v\xe0o năm 2024).
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        Điểm "ăn tiền" nhất của Exness ch\xednh l\xe0 cơ chế <strong>Nạp R\xfat Tức Th\xec (Instant Withdrawal)</strong>. Hệ thống xử l\xfd tự động 24/7 cho ph\xe9p tiền về t\xe0i khoản ng\xe2n h\xe0ng của bạn chỉ trong v\xe0i gi\xe2y, kể cả Thứ 7 v\xe0 Chủ Nhật.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p Hoạt Động
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">FCA (Vương Quốc Anh)</div>
                            <div class="text-xs text-muted-foreground">Giấy ph\xe9p uy t\xedn nhất ng\xe0nh t\xe0i ch\xednh, bảo vệ quyền lợi tối đa cho nh\xe0 đầu tư.</div>
                        </div>
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">CySEC (S\xedp)</div>
                            <div class="text-xs text-muted-foreground">Cho ph\xe9p hoạt động hợp ph\xe1p tr\xean to\xe0n ch\xe2u \xc2u.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> C\xe1c Loại T\xe0i Khoản
                    </h3>
                    <ul class="space-y-4">
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">1. Standard & Standard Cent</span>
                                <span class="bg-green-500/10 text-green-600 px-2 py-0.5 rounded text-xs font-bold">Phổ biến nhất</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Chỉ từ $1 nạp vốn. Ph\xf9 hợp cho người mới bắt đầu (Newbie). Spread ổn định từ 0.3 pips. <br>
                                <strong>Đ\xf2n bẩy: V\xf4 cực (1:Unlimited)</strong> - Duy nhất tr\xean thị trường.
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">2. Raw Spread</span>
                                <span class="bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded text-xs font-bold">Cho Scalper</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Spread cặp ch\xednh cố định ở <strong>0.0 pips</strong>. Ph\xed hoa hồng $7/lot. <br>
                                L\xfd tưởng cho c\xe1c chiến lược lướt s\xf3ng (Scalping) v\xe0 giao dịch thuật to\xe1n (EA).
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">3. Zero Account</span>
                                <span class="bg-purple-500/10 text-purple-600 px-2 py-0.5 rounded text-xs font-bold">Spread 0.0</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Cam kết Spread 0.0 pips trong 95% thời gian giao dịch cho 30 cặp tiền ch\xednh. Ph\xed hoa hồng từ $3.5/lot/chiều.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:4,rank:4,name:"XTB",slug:"xtb",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xtb-sanuytin.jpg",score:9.5,minDep:"$0",maxLev:"1:500",license:"FCA, CySEC, KNF",features:["Nền tảng xStation 5 xịn","Niêm yết chứng khoán","Miễn phí qua đêm vàng"],reviewLink:"xtb",registerLink:"#",foundedYear:"2002",headquarters:"Warsaw, Poland",platforms:["xStation 5","xStation Mobile"],depositMethods:["NganLuong","Visa","Skrill"],pros:["Nền tảng xStation 5 độc quyền cực kỳ mượt mà","Được niêm yết trên sàn chứng khoán (minh bạch tài chính)","Miễn phí phí qua đêm (Swap) cho lệnh Vàng và nhiều cặp tiền"],avgSpread:"0.8 pips",commission:"Không phí",cons:["Không hỗ trợ MT4/MT5 (có thể khó quen với người cũ)","Đòn bẩy tối đa chỉ 1:500"],longDescription:`
            <p class="mb-4"><strong>XTB</strong> l\xe0 một Fintech company thực thụ trong lĩnh vực Forex. Kh\xe1c với c\xe1c s\xe0n kh\xe1c d\xf9ng MT4, XTB ph\xe1t triển nền tảng xStation 5 đoạt nhiều giải thưởng, mang lại trải nghiệm giao dịch vượt trội.</p>
        `},{id:5,rank:5,name:"FBS",slug:"fbs",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fbs-sanuytin.png",score:9.3,minDep:"$1",maxLev:"1:3000",license:"CySEC, ASIC, FSC",features:["Nhiều loại tài khoản","Copy trade tốt","Nạp rút nhanh"],reviewLink:"fbs",registerLink:"#",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FBS Trader"],depositMethods:["Internet Banking","Visa","USDT"],pros:["Đòn bẩy cực cao lên tới 1:3000","Nhiều loại tài khoản phù hợp mọi trader (Cent, Micro, Standard)","Ứng dụng Copy Trade tốt"],avgSpread:"0.7 pips",commission:"Không phí",cons:["Spread tài khoản thường hơi cao","Giấy phép quốc tế chưa mạnh bằng top đầu"],longDescription:`
            <p class="mb-4"><strong>FBS</strong> l\xe0 lựa chọn phổ biến cho c\xe1c trader mới bắt đầu nhờ y\xeau cầu vốn thấp v\xe0 t\xe0i khoản Cent. S\xe0n c\xf3 mặt tại hơn 150 quốc gia v\xe0 nổi tiếng với c\xe1c hoạt động marketing s\xf4i nổi.</p>
        `},{id:6,rank:6,name:"HFM",slug:"hfm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/hfm-sanuytin.jpg",score:9.2,minDep:"$5",maxLev:"1:2000",license:"FCA, CySEC, FSA",features:["Bonus nạp tiền lớn","Nhiều công cụ GD","Bảo hiểm vốn"],reviewLink:"hfm",registerLink:"#",foundedYear:"2010",headquarters:"Larnaca, Cyprus",platforms:["MT4","MT5","HFM App"],depositMethods:["Bank Transfer","Crypto","Cards","MoMo"],pros:["Chương trình Bảo hiểm Trách nhiệm Dân sự lên đến 5.000.000 EUR","Tài khoản PAMM chất lượng cho nhà đầu tư","Công cụ phân tích độc quyền Premium Trader Tools","Nhiều loại tài khoản linh hoạt (Cent, Zero, Premium)"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Quy trình xác minh danh tính đôi khi hơi lâu (24h)","Không hỗ trợ PayPal cho khách hàng Việt Nam"],longDescription:`
            <p class="mb-4"><strong>HFM</strong> (trước đ\xe2y l\xe0 HotForex) l\xe0 một thương hiệu m\xf4i giới đa t\xe0i sản từng đoạt giải thưởng. Với hơn 2.5 triệu t\xe0i khoản thực đ\xe3 mở, HFM khẳng định vị thế l\xe0 một trong những s\xe0n giao dịch lớn nhất thế giới.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">An to\xe0n v\xe0 Bảo mật</h3>
            <p class="mb-4">HFM nổi bật với g\xf3i bảo hiểm l\xe1 chắn thị trường trị gi\xe1 5 triệu Euro, bảo vệ kh\xe1ch h\xe0ng khỏi c\xe1c lỗi sai s\xf3t, gian lận hoặc sơ suất c\xf3 thể dẫn đến thiệt hại về t\xe0i ch\xednh. Đ\xe2y l\xe0 điểm cộng cực lớn về uy t\xedn.</p>
        `},{id:7,rank:7,name:"FXTM",slug:"fxtm",logo:"https://sanuytin.net/wp-content/uploads/2025/11/fxtm-san-forex-uy-tin-2025.jpeg",score:9.1,minDep:"$10",maxLev:"1:2000",license:"FCA, CySEC",features:["Đào tạo tốt","Tài khoản ECN","Hỗ trợ nhiệt tình"],reviewLink:"fxtm",registerLink:"#",foundedYear:"2011",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FXTM Trader"],depositMethods:["Internet Banking","E-wallets","Visa/Master"],pros:["Tốc độ khớp lệnh ECN cực nhanh, trung bình vài mili giây","Nền tảng FXTM Invest (Copy Trade) rất phát triển","Kho tài liệu giáo dục và hội thảo online phong phú","Tách biệt vốn khách hàng tại các ngân hàng Tier-1"],avgSpread:"1.5 pips",commission:"Không phí",cons:["Phí rút tiền qua một số ví điện tử có thể cao","Giao diện web quản lý tài khoản hơi rối với người mới"],longDescription:`
            <p class="mb-4"><strong>FXTM</strong> (ForexTime) được biết đến l\xe0 nh\xe0 m\xf4i giới c\xf3 tốc độ tăng trưởng nhanh nhất thế giới. S\xe0n tập trung mạnh v\xe0o gi\xe1o dục v\xe0 c\xf4ng nghệ khớp lệnh ECN, mang lại trải nghiệm giao dịch chuy\xean nghiệp.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Gi\xe1o dục v\xe0 Đ\xe0o tạo</h3>
            <p class="mb-4">FXTM đầu tư rất mạnh v\xe0o mảng đ\xe0o tạo với h\xe0ng loạt Ebook, Video hướng dẫn v\xe0 c\xe1c buổi Webinar h\xe0ng tuần. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c trader mới muốn n\xe2ng cao kiến thức b\xe0i bản.</p>
        `},{id:8,rank:8,name:"FxPro",slug:"fxpro",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fxpro-sanuytin.jpg",score:8.9,minDep:"$100",maxLev:"1:500",license:"FCA, CySEC, SCB",features:["Thương hiệu toàn cầu","Không phí hoa hồng","Nhiều nền tảng"],reviewLink:"fxpro",registerLink:"#",foundedYear:"2006",headquarters:"London, UK",platforms:["cTrader","MT4","MT5","FxPro Edge"],depositMethods:["Bank","Visa","PayPal","Skrill"],pros:["Thương hiệu toàn cầu uy tín, nhà tài trợ đội đua McLaren F1","Nền tảng cTrader mạnh mẽ, hỗ trợ đo lường độ sâu thị trường (DOM)","Mô hình No Dealing Desk (NDD) minh bạch hoàn toàn","Ví FxPro Wallet giúp quản lý vốn an toàn, tách biệt rủi ro"],avgSpread:"1.2 pips",commission:"Không phí",cons:["Spread trên tài khoản MT4 không cạnh tranh bằng Exness hay Vantage","Quy trình mở tài khoản yêu cầu xác minh khá kỹ"],longDescription:`
            <p class="mb-4"><strong>FxPro</strong> l\xe0 "\xf4ng lớn" thực thụ trong ng\xe0nh Forex với trụ sở ch\xednh tại London. Hoạt động từ 2006, FxPro đ\xe3 phục vụ kh\xe1ch h\xe0ng tại hơn 170 quốc gia v\xe0 xử l\xfd h\xe0ng ngh\xecn lệnh mỗi gi\xe2y.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Nền tảng cTrader</h3>
            <p class="mb-4">FxPro l\xe0 một trong những broker cung cấp nền tảng cTrader tốt nhất hiện nay. cTrader cho ph\xe9p trader nh\xecn thấy độ s\xe2u thị trường (Market Depth) v\xe0 khớp lệnh VWAP (Volume Weighted Average Price), cực kỳ ph\xf9 hợp cho Scalping chuy\xean nghiệp.</p>
        `},{id:9,rank:9,name:"Tickmill",slug:"tickmill",logo:"https://sanuytin.net/wp-content/uploads/2025/10/tickmill-sanuytin.jpg",score:8.6,minDep:"$100",maxLev:"1:1000",license:"FCA, CySEC, FSA",features:["Spread thấp ổn định","Không phí hoa hồng","Execution nhanh"],reviewLink:"tickmill",registerLink:"#",foundedYear:"2014",headquarters:"Mahe, Seychelles",platforms:["MT4","MT5"],depositMethods:["Bank Transfer","Crypto","Neteller","Skrill"],pros:["Phí hoa hồng (Commission) thấp nhất thị trường: 2 đơn vị tiền tệ/lot","Chào đón mọi chiến lược giao dịch: Scalping, News Trading, EA","Không có phí ẩn, spread cực thấp trên tài khoản Pro","Giấy phép FCA Anh Quốc uy tín"],avgSpread:"0.0 pips",commission:"$2/lot",cons:["Ít sản phẩm giao dịch (chủ yếu là Forex, Vàng, Dầu, một số Index)","Không có tài khoản Cent (chỉ có Pro và Classic)"],longDescription:`
            <p class="mb-4"><strong>Tickmill</strong> l\xe0 thi\xean đường cho d\xe2n Scalping v\xe0 Algo Trading (Giao dịch thuật to\xe1n). S\xe0n nổi tiếng với điều kiện giao dịch "Raw" nhất: spread thấp, ph\xed hoa hồng cực rẻ v\xe0 tốc độ khớp lệnh tuyệt vời.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Chi ph\xed giao dịch</h3>
            <p class="mb-4">Nếu bạn quan t\xe2m đến chi ph\xed, Tickmill l\xe0 lựa chọn số 1. T\xe0i khoản Pro của họ c\xf3 spread từ 0.0 pips v\xe0 ph\xed hoa hồng chỉ 2 USD/lot/chiều, thấp hơn 30-40% so với mức trung b\xecnh ng\xe0nh (thường l\xe0 3.5 USD).</p>
        `},{id:10,rank:10,name:"Pepperstone",slug:"pepperstone",logo:"https://sanuytin.net/wp-content/uploads/2025/10/Pepperstone-sanuytin.jpg",score:8.3,minDep:"$0 (rec. $200)",maxLev:"1:500",license:"ASIC, FCA, SCB",features:["Khớp lệnh cực nhanh","Không Dealing Desk","Hỗ trợ cTrader"],reviewLink:"/pepperstone",registerLink:"#",foundedYear:"2010",headquarters:"Melbourne, Australia",platforms:["cTrader","MT4","MT5","TradingView"],depositMethods:["Internet Banking","Visa","PayPal"],pros:["Hỗ trợ kết nối trực tiếp với TradingView để giao dịch","Thanh khoản sâu từ 22 ngân hàng Tier-1","Dịch vụ chăm sóc khách hàng được đánh giá 5 sao","Khớp lệnh cực nhanh dưới 30ms"],avgSpread:"0.0 pips",commission:"$3.5/lot",cons:["Yêu cầu nạp tiền lần đầu $200 (hơi cao với sinh viên)","Không có nhiều chương trình Bonus như XM hay Exness"],longDescription:`
            <p class="mb-4"><strong>Pepperstone</strong> l\xe0 niềm tự h\xe0o của \xdac trong lĩnh vực Fintech. S\xe0n nổi tiếng với tốc độ, sự ổn định v\xe0 hỗ trợ c\xf4ng nghệ tận răng. Pepperstone l\xe0 một trong số \xedt broker cho ph\xe9p bạn giao dịch trực tiếp tr\xean biểu đồ TradingView.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">C\xf4ng nghệ ECN/STP</h3>
            <p class="mb-4">Pepperstone hoạt động theo m\xf4 h\xecnh No Dealing Desk thực thụ. Mọi lệnh của bạn được đẩy trực tiếp ra thị trường li\xean ng\xe2n h\xe0ng với độ trễ gần như bằng 0. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c hệ thống giao dịch tự động (EA).</p>
        `}];e.s(["brokers",0,t])},94351,e=>{"use strict";let t=(0,e.i(75254).default)("house",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]]);e.s(["Home",()=>t],94351)},10980,e=>{"use strict";let t=(0,e.i(75254).default)("book-open",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);e.s(["BookOpen",()=>t],10980)},86536,e=>{"use strict";let t=(0,e.i(75254).default)("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);e.s(["Eye",()=>t],86536)},70956,e=>{"use strict";let t=(0,e.i(75254).default)("list",[["path",{d:"M3 5h.01",key:"18ugdj"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M3 19h.01",key:"noohij"}],["path",{d:"M8 5h13",key:"1pao27"}],["path",{d:"M8 12h13",key:"1za7za"}],["path",{d:"M8 19h13",key:"m83p4d"}]]);e.s(["List",()=>t],70956)},62031,e=>{"use strict";let t=(0,e.i(75254).default)("share-2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]);e.s(["Share2",()=>t],62031)},83157,94983,71689,74886,43531,e=>{"use strict";var t=e.i(75254);let n=(0,t.default)("facebook",[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]]);e.s(["Facebook",()=>n],83157);let s=(0,t.default)("message-circle",[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]);e.s(["MessageCircle",()=>s],94983);let r=(0,t.default)("arrow-left",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);e.s(["ArrowLeft",()=>r],71689);let i=(0,t.default)("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);e.s(["Copy",()=>i],74886);let a=(0,t.default)("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);e.s(["Check",()=>a],43531)},40337,e=>{"use strict";var t=e.i(43476),n=e.i(71645),s=e.i(18566),r=e.i(22016),i=e.i(7471),a=e.i(94351),o=e.i(63059),h=e.i(87316),c=e.i(3116),l=e.i(86536),d=e.i(62031),x=e.i(83157),g=e.i(78021),p=e.i(10980),u=e.i(55900),m=e.i(94983),f=e.i(71689),b=e.i(72520),v=e.i(70956),y=e.i(74886),k=e.i(43531);let N=(0,e.i(75254).default)("graduation-cap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);var j=e.i(83086),w=e.i(42942);let M=[{id:101,slug:"forex-la-gi",title:"Forex là gì? Hướng dẫn đầu tư Forex toàn tập cho người mới",excerpt:"Khái niệm Forex là gì? Tìm hiểu về thị trường ngoại hối, cách thức hoạt động, các phiên giao dịch và cơ hội kiếm tiền từ Forex.",published_at:"2026-01-27",category:"kien-thuc",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/forex-la-gi.jpg",content:`
            <h2>1. Forex l\xe0 g\xec?</h2>
            <p><strong>Forex</strong> (viết tắt của <em>Foreign Exchange</em>), hay c\xf2n gọi l\xe0 thị trường ngoại hối, l\xe0 nơi diễn ra việc trao đổi c\xe1c loại tiền tệ của c\xe1c quốc gia kh\xe1c nhau.</p>
            <p>V\xed dụ đơn giản: Khi bạn đi du lịch từ Việt Nam sang Mỹ, bạn đổi tiền VND lấy USD. H\xe0nh động đ\xf3 ch\xednh l\xe0 bạn đ\xe3 tham gia v\xe0o thị trường Forex.</p>
            <p>Tuy nhi\xean, trong đầu tư Forex, mục ti\xeau của bạn kh\xf4ng phải l\xe0 đổi tiền để ti\xeau x\xe0i, m\xe0 l\xe0 <strong>kiếm lợi nhuận từ sự ch\xeanh lệch tỷ gi\xe1</strong> giữa c\xe1c cặp tiền tệ.</p>
            
            <h2>2. Thị trường Forex hoạt động như thế n\xe0o?</h2>
            <p>Kh\xe1c với chứng kho\xe1n nơi bạn mua cổ phiếu của một c\xf4ng ty, trong Forex, h\xe0ng h\xf3a ch\xednh l\xe0 <strong>Tiền</strong>. Giao dịch Forex lu\xf4n diễn ra theo từng <strong>cặp tiền tệ</strong>.</p>
            <p>V\xed dụ cặp tiền phổ biến nhất: <strong>EUR/USD</strong></p>
            <ul>
                <li>Đồng tiền đứng trước (EUR) gọi l\xe0 <strong>Đồng tiền cơ sở (Base Currency)</strong>.</li>
                <li>Đồng tiền đứng sau (USD) gọi l\xe0 <strong>Đồng tiền định gi\xe1 (Quote Currency)</strong>.</li>
            </ul>
            
            <h2>3. Ai tham gia v\xe0o thị trường n\xe0y?</h2>
            <p>Thị trường Forex l\xe0 s\xe2n chơi của nhiều "tay to" lớn:</p>
            <ul>
                <li><strong>Ng\xe2n h\xe0ng trung ương:</strong> Như Fed (Mỹ), ECB (Ch\xe2u \xc2u) can thiệp để ổn định tiền tệ quốc gia.</li>
                <li><strong>C\xe1c ng\xe2n h\xe0ng thương mại lớn:</strong> Deutsche Bank, Citi, JP Morgan... chiếm phần lớn volume giao dịch.</li>
                <li><strong>Quỹ đầu tư & C\xf4ng ty đa quốc gia:</strong> Giao dịch để ph\xf2ng ngừa rủi ro tỷ gi\xe1.</li>
                <li><strong>Trader nhỏ lẻ (Retail Traders):</strong> Ch\xednh l\xe0 ch\xfang ta, những người giao dịch th\xf4ng qua c\xe1c S\xe0n m\xf4i giới (Brokers).</li>
            </ul>
            
            <h2>4. Thời gian giao dịch Forex</h2>
            <p>Một điểm cộng lớn của Forex l\xe0 thị trường hoạt động <strong>24/5</strong> (từ thứ 2 đến thứ 6). Do c\xe1c trung t\xe2m t\xe0i ch\xednh to\xe0n cầu mở cửa nối tiếp nhau:</p>
            <ul>
                <li><strong>Phi\xean \xdac (Sydney):</strong> Mở cửa s\xe1ng sớm (5h00 - 14h00 VN).</li>
                <li><strong>Phi\xean \xc1 (Tokyo):</strong> S\xf4i động với c\xe1c đồng JPY, AUD (6h00 - 15h00 VN).</li>
                <li><strong>Phi\xean \xc2u (London):</strong> Phi\xean giao dịch nhộn nhịp nhất (14h00 - 23h00 VN).</li>
                <li><strong>Phi\xean Mỹ (New York):</strong> Biến động mạnh nhất (19h00 - 4h00 s\xe1ng h\xf4m sau VN).</li>
            </ul>
            
            <h2>5. L\xe0m thế n\xe0o để bắt đầu kiếm tiền từ Forex?</h2>
            <p>Để bắt đầu, bạn kh\xf4ng cần h\xe0ng tỷ đồng như c\xe1c ng\xe2n h\xe0ng. Nhờ cơ chế <strong>Đ\xf2n bẩy (Leverage)</strong>, bạn c\xf3 thể bắt đầu giao dịch chỉ với số vốn rất nhỏ ($50 - $100).</p>
            <h3>Quy tr\xecnh cơ bản cho người mới:</h3>
            <ol>
                <li><strong>T\xecm hiểu kiến thức:</strong> Đọc c\xe1c b\xe0i viết về Nến Nhật, Quản l\xfd vốn.</li>
                <li><strong>Chọn s\xe0n uy t\xedn:</strong> Mở t\xe0i khoản tại c\xe1c s\xe0n được cấp ph\xe9p (như Exness, Vantage, XM...).</li>
                <li><strong>Giao dịch Demo:</strong> Tập luyện với tiền ảo để l\xe0m quen thị trường.</li>
                <li><strong>Nạp vốn & Giao dịch thật:</strong> Bắt đầu với số vốn nhỏ v\xe0 tu\xe2n thủ kỷ luật.</li>
            </ol>
        `},{id:102,slug:"cach-doc-bieu-do-nen-nhat",title:"Cách đọc biểu đồ nến Nhật - Hướng dẫn cho người mới",excerpt:"Học cách đọc và phân tích biểu đồ nến Nhật (Japanese Candlestick) - công cụ không thể thiếu của mọi trader.",published_at:"2026-01-26",category:"kien-thuc",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/nen-nhat.jpg",content:`
            <h2>1. Nến Nhật l\xe0 g\xec?</h2>
            <p>Nến Nhật (Japanese Candlestick) l\xe0 một phương ph\xe1p biểu diễn biến động gi\xe1 được ph\xe1t triển bởi c\xe1c thương nh\xe2n gạo Nhật Bản từ thế kỷ 18.</p>
            
            <h2>2. Cấu tạo của một c\xe2y nến</h2>
            <p>Mỗi c\xe2y nến c\xf3 4 th\xe0nh phần ch\xednh:</p>
            <ul>
                <li><strong>Gi\xe1 mở cửa (Open):</strong> Gi\xe1 tại thời điểm bắt đầu phi\xean giao dịch</li>
                <li><strong>Gi\xe1 đ\xf3ng cửa (Close):</strong> Gi\xe1 tại thời điểm kết th\xfac phi\xean</li>
                <li><strong>Gi\xe1 cao nhất (High):</strong> Mức gi\xe1 cao nhất trong phi\xean</li>
                <li><strong>Gi\xe1 thấp nhất (Low):</strong> Mức gi\xe1 thấp nhất trong phi\xean</li>
            </ul>
            
            <h2>3. Ph\xe2n loại nến</h2>
            <h3>Nến tăng (Bullish Candle)</h3>
            <p>Khi gi\xe1 đ\xf3ng cửa cao hơn gi\xe1 mở cửa, nến c\xf3 m\xe0u xanh l\xe1 hoặc trắng.</p>
            
            <h3>Nến giảm (Bearish Candle)</h3>
            <p>Khi gi\xe1 đ\xf3ng cửa thấp hơn gi\xe1 mở cửa, nến c\xf3 m\xe0u đỏ hoặc đen.</p>
        `},{id:103,slug:"quan-ly-von-trading",title:"Quản lý vốn trong Trading - Bí quyết sống sót",excerpt:"Quản lý vốn (Money Management) là kỹ năng quan trọng nhất quyết định sự thành bại trong trading.",published_at:"2026-01-25",category:"kien-thuc",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/quan-ly-von.jpg",content:`
            <h2>1. Tại sao quản l\xfd vốn quan trọng?</h2>
            <p>90% trader thua lỗ kh\xf4ng phải v\xec kh\xf4ng biết ph\xe2n t\xedch, m\xe0 v\xec quản l\xfd vốn k\xe9m. Một chiến lược c\xf3 tỷ lệ thắng 60% vẫn c\xf3 thể ch\xe1y t\xe0i khoản nếu bạn kh\xf4ng kiểm so\xe1t được rủi ro.</p>
            
            <h2>2. Quy tắc 1-2%</h2>
            <p>Quy tắc v\xe0ng: Kh\xf4ng bao giờ rủi ro qu\xe1 1-2% t\xe0i khoản cho một giao dịch.</p>
            
            <h2>3. Risk/Reward Ratio</h2>
            <p>Lu\xf4n đảm bảo tỷ lệ Risk/Reward tối thiểu 1:2. Nghĩa l\xe0 nếu bạn sẵn s\xe0ng thua $100, mục ti\xeau lợi nhuận phải l\xe0 $200.</p>
        `}];function T(){var e;let{slug:T}=(0,s.useParams)(),[C,S]=(0,n.useState)(null),[F,L]=(0,n.useState)([]),[q,P]=(0,n.useState)(!0),[V,D]=(0,n.useState)(""),[A,$]=(0,n.useState)(!1),[B,E]=(0,n.useState)(0),K=(0,n.useRef)(null),{processedContent:H,toc:z}=(0,n.useMemo)(()=>{var e;let t,n;if(!C?.content)return{processedContent:"",toc:[]};let s=(e=C.content,t=[],n=0,{processedHtml:e.replace(/<(h[23])([^>]*)>(.*?)<\/\1>/gi,(e,s,r,i)=>{let a=`section-${n}`,o=i.replace(/<[^>]*>/g,"").trim();return t.push({id:a,text:o,level:"h2"===s.toLowerCase()?2:3}),n++,`<${s}${r} id="${a}">${i}</${s}>`}),tocItems:t});return{processedContent:s.processedHtml,toc:s.tocItems}},[C?.content]);if((0,n.useEffect)(()=>{!async function(){if(!T||"string"!=typeof T)return;let e=await (0,i.getPostBySlug)(T);if(e)S(e),L((await (0,i.getPosts)(!0)).filter(t=>t.id!==e.id&&t.category===e.category).slice(0,4));else{let e=M.find(e=>e.slug===T);e&&(S(e),L(M.filter(e=>e.slug!==T).slice(0,4)))}P(!1)}()},[T]),(0,n.useEffect)(()=>{let e=()=>{if(!K.current)return;let e=K.current,t=window.scrollY,n=e.offsetHeight,s=window.innerHeight;E(Math.min(100,Math.max(0,(t-e.offsetTop+s)/(n+s)*100))),e.querySelectorAll("h2, h3").forEach(e=>{let t=e.getBoundingClientRect();t.top<=150&&t.bottom>=0&&D(e.id)})};return window.addEventListener("scroll",e),()=>window.removeEventListener("scroll",e)},[C]),q)return(0,t.jsx)("main",{className:"min-h-screen bg-background pt-[160px]",children:(0,t.jsx)("div",{className:"container-custom max-w-7xl py-12",children:(0,t.jsxs)("div",{className:"grid lg:grid-cols-12 gap-8",children:[(0,t.jsxs)("div",{className:"lg:col-span-8 space-y-6",children:[(0,t.jsx)("div",{className:"h-8 bg-slate-800 rounded w-1/2 animate-pulse"}),(0,t.jsx)("div",{className:"h-12 bg-slate-800 rounded animate-pulse"}),(0,t.jsx)("div",{className:"aspect-video bg-slate-800 rounded-2xl animate-pulse"})]}),(0,t.jsx)("div",{className:"lg:col-span-4",children:(0,t.jsx)("div",{className:"h-64 bg-slate-800 rounded-2xl animate-pulse"})})]})})});if(!C)return(0,t.jsx)("main",{className:"min-h-screen bg-background pt-[160px] flex items-center justify-center",children:(0,t.jsxs)("div",{className:"text-center space-y-4",children:[(0,t.jsx)("h1",{className:"text-2xl font-bold text-foreground",children:"Bài viết không tồn tại"}),(0,t.jsx)(r.default,{href:"/kien-thuc-forex",className:"text-primary hover:underline",children:"← Quay lại Kiến thức Forex"})]})});let R=Math.ceil((C.content||"").replace(/<[^>]*>/g,"").split(/\s+/).length/200);return(0,t.jsxs)("main",{className:"min-h-screen bg-background pt-[160px]",children:[(0,t.jsx)("div",{className:"fixed top-0 left-0 right-0 h-1 bg-slate-800 z-50",children:(0,t.jsx)("div",{className:"h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-150",style:{width:`${B}%`}})}),(0,t.jsx)("div",{className:"bg-secondary/30 border-b border-border",children:(0,t.jsx)("div",{className:"container-custom max-w-7xl py-3",children:(0,t.jsxs)("div",{className:"flex items-center gap-2 text-xs md:text-sm text-muted-foreground",children:[(0,t.jsxs)(r.default,{href:"/",className:"hover:text-primary flex items-center gap-1 transition-colors",children:[(0,t.jsx)(a.Home,{size:14})," Trang chủ"]}),(0,t.jsx)(o.ChevronRight,{size:14}),(0,t.jsx)(r.default,{href:"/kien-thuc-forex",className:"hover:text-primary transition-colors",children:"Kiến thức Forex"}),(0,t.jsx)(o.ChevronRight,{size:14}),(0,t.jsx)("span",{className:"text-foreground font-medium truncate max-w-[200px]",children:C.title})]})})}),(0,t.jsx)("div",{className:"container-custom max-w-7xl py-8 md:py-12",children:(0,t.jsxs)("div",{className:"grid lg:grid-cols-12 gap-8 xl:gap-12",children:[(0,t.jsxs)("article",{className:"lg:col-span-8",children:[(0,t.jsxs)("header",{className:"mb-8",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-4",children:[(0,t.jsx)("div",{className:"p-2 bg-green-500/10 rounded-lg text-green-500",children:(0,t.jsx)(N,{size:20})}),(0,t.jsx)("span",{className:"px-3 py-1 bg-green-500/10 text-green-500 text-xs font-bold rounded-full",children:"Kiến thức Forex"})]}),(0,t.jsx)("h1",{className:"text-3xl md:text-4xl lg:text-5xl font-extrabold text-foreground mb-6 leading-tight tracking-tight",children:C.title}),C.excerpt&&(0,t.jsx)("p",{className:"text-lg md:text-xl text-muted-foreground leading-relaxed mb-6",children:C.excerpt}),(0,t.jsxs)("div",{className:"flex flex-wrap items-center gap-4 md:gap-6 text-sm text-muted-foreground pb-6 border-b border-border",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2",children:[(0,t.jsx)("div",{className:"w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white font-bold",children:"SUT"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{className:"font-medium text-foreground",children:"Sàn Uy Tín"}),(0,t.jsx)("p",{className:"text-xs text-muted-foreground",children:"Chuyên gia Forex"})]})]}),(0,t.jsxs)("div",{className:"flex items-center gap-4 flex-wrap",children:[(0,t.jsxs)("span",{className:"flex items-center gap-1.5",children:[(0,t.jsx)(h.Calendar,{size:14,className:"text-green-500"}),(e=C.published_at)?new Date(e).toLocaleDateString("vi-VN",{day:"2-digit",month:"long",year:"numeric"}):""]}),(0,t.jsxs)("span",{className:"flex items-center gap-1.5",children:[(0,t.jsx)(c.Clock,{size:14,className:"text-green-500"}),R," phút đọc"]}),(0,t.jsxs)("span",{className:"flex items-center gap-1.5",children:[(0,t.jsx)(l.Eye,{size:14,className:"text-green-500"}),"2.5K lượt xem"]})]})]})]}),C.featured_image&&(0,t.jsx)("div",{className:"aspect-video rounded-2xl overflow-hidden mb-8 bg-secondary/50 shadow-lg",children:(0,t.jsx)("img",{src:C.featured_image,alt:C.title,className:"w-full h-full object-cover"})}),(0,t.jsx)("div",{ref:K,className:"prose prose-lg dark:prose-invert max-w-none prose-headings:font-bold prose-headings:text-foreground prose-headings:tracking-tight prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4 prose-h2:pb-2 prose-h2:border-b prose-h2:border-border/40 prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3 prose-h3:text-green-500 prose-p:text-muted-foreground prose-p:leading-8 prose-p:mb-5 prose-li:text-muted-foreground prose-li:marker:text-green-500 prose-strong:text-foreground prose-strong:font-semibold prose-a:text-green-500 prose-a:no-underline hover:prose-a:underline prose-blockquote:border-l-4 prose-blockquote:border-green-500 prose-blockquote:bg-secondary/30 prose-blockquote:rounded-r-lg prose-blockquote:py-4 prose-blockquote:px-6 prose-blockquote:not-italic prose-img:rounded-xl prose-img:shadow-md prose-code:bg-secondary prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-green-500",dangerouslySetInnerHTML:{__html:H}}),(0,t.jsxs)("div",{className:"mt-12 p-8 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-2xl text-center",children:[(0,t.jsx)(j.Sparkles,{className:"w-12 h-12 text-green-500 mx-auto mb-4"}),(0,t.jsx)("h3",{className:"text-2xl font-bold text-foreground mb-4",children:"Sẵn sàng bắt đầu?"}),(0,t.jsx)("p",{className:"text-muted-foreground mb-6 max-w-lg mx-auto",children:"Thị trường Forex mang lại cơ hội lợi nhuận không giới hạn. Hãy chọn một sàn uy tín để bắt đầu hành trình của bạn."}),(0,t.jsxs)(r.default,{href:"/#ranking",className:"inline-flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 px-8 rounded-xl shadow-lg shadow-green-500/30 hover:shadow-green-500/50 transition-all hover:-translate-y-1",children:["Xem Top Sàn Uy Tín ",(0,t.jsx)(o.ChevronRight,{size:18})]})]}),(0,t.jsxs)("div",{className:"mt-10 grid md:grid-cols-2 gap-4",children:[(0,t.jsxs)(r.default,{href:"/kien-thuc-forex",className:"group flex items-center gap-4 p-4 bg-card border border-border rounded-xl hover:border-green-500/50 transition-colors",children:[(0,t.jsx)("div",{className:"p-2 bg-secondary rounded-lg group-hover:bg-green-500/10 transition-colors",children:(0,t.jsx)(f.ArrowLeft,{size:20,className:"text-muted-foreground group-hover:text-green-500"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("span",{className:"text-xs text-muted-foreground",children:"Quay lại"}),(0,t.jsx)("p",{className:"text-foreground font-medium group-hover:text-green-500 transition-colors",children:"Tất cả bài học"})]})]}),F[0]&&(0,t.jsxs)(r.default,{href:`/kien-thuc-forex/${F[0].slug}`,className:"group flex items-center gap-4 p-4 bg-card border border-border rounded-xl hover:border-green-500/50 transition-colors text-right md:justify-end",children:[(0,t.jsx)("div",{className:"md:order-2 p-2 bg-secondary rounded-lg group-hover:bg-green-500/10 transition-colors",children:(0,t.jsx)(b.ArrowRight,{size:20,className:"text-muted-foreground group-hover:text-green-500"})}),(0,t.jsxs)("div",{className:"md:order-1",children:[(0,t.jsx)("span",{className:"text-xs text-muted-foreground",children:"Bài tiếp theo"}),(0,t.jsx)("p",{className:"text-foreground font-medium line-clamp-1 group-hover:text-green-500 transition-colors",children:F[0].title})]})]})]})]}),(0,t.jsx)("aside",{className:"lg:col-span-4",children:(0,t.jsxs)("div",{className:"sticky top-28 space-y-6",children:[z.length>0&&(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-5 hidden lg:block",children:[(0,t.jsxs)("h4",{className:"font-bold text-foreground mb-4 flex items-center gap-2",children:[(0,t.jsx)(v.List,{size:18,className:"text-green-500"}),"Mục lục bài viết"]}),(0,t.jsx)("nav",{className:"space-y-2 max-h-[300px] overflow-y-auto pr-2",children:z.map(e=>(0,t.jsx)("a",{href:`#${e.id}`,className:`block text-sm py-1.5 px-3 rounded-lg transition-all ${3===e.level?"pl-6":""} ${V===e.id?"bg-green-500/10 text-green-500 font-medium border-l-2 border-green-500":"text-muted-foreground hover:text-foreground hover:bg-secondary/50"}`,children:e.text},e.id))})]}),(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-5 hidden lg:block",children:[(0,t.jsxs)("h4",{className:"font-bold text-foreground mb-4 flex items-center gap-2",children:[(0,t.jsx)(d.Share2,{size:18,className:"text-green-500"}),"Chia sẻ kiến thức"]}),(0,t.jsxs)("div",{className:"flex flex-wrap gap-2",children:[(0,t.jsxs)("button",{className:"flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors",children:[(0,t.jsx)(x.Facebook,{size:18}),"Facebook"]}),(0,t.jsxs)("button",{className:"flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-medium transition-colors",children:[(0,t.jsx)(g.Twitter,{size:18}),"Twitter"]})]}),(0,t.jsxs)("button",{onClick:()=>{navigator.clipboard.writeText(window.location.href),$(!0),setTimeout(()=>$(!1),2e3)},className:"w-full mt-3 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-secondary hover:bg-slate-700 text-foreground font-medium transition-colors",children:[A?(0,t.jsx)(k.Check,{size:18,className:"text-green-500"}):(0,t.jsx)(y.Copy,{size:18}),A?"Đã sao chép!":"Sao chép link"]})]}),(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-5",children:[(0,t.jsxs)("h4",{className:"font-bold text-foreground mb-4 flex items-center gap-2 text-sm uppercase tracking-wide",children:[(0,t.jsx)(p.BookOpen,{size:16,className:"text-green-500"}),"Sàn Forex Uy Tín"]}),(0,t.jsx)("div",{className:"space-y-3",children:w.brokers.slice(0,4).map((e,n)=>(0,t.jsxs)(r.default,{href:`/${e.slug}`,className:"flex items-center gap-3 group hover:bg-secondary/50 p-2 -mx-2 rounded-lg transition-colors",children:[(0,t.jsx)("div",{className:`
                                                w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
                                                ${0===n?"bg-yellow-500 text-white":1===n?"bg-gray-300 text-gray-700":2===n?"bg-orange-400 text-white":"bg-secondary text-muted-foreground"}
                                            `,children:n+1}),(0,t.jsx)("img",{src:e.logo,alt:e.name,className:"w-8 h-8 object-contain rounded-md bg-white border border-border/50"}),(0,t.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,t.jsx)("div",{className:"font-bold text-sm text-foreground group-hover:text-green-500 truncate",children:e.name}),(0,t.jsxs)("div",{className:"text-xs text-muted-foreground",children:[e.score.toFixed(1),"/10"]})]})]},e.id))})]}),F.length>0&&(0,t.jsxs)("div",{className:"bg-card border border-border rounded-2xl p-5",children:[(0,t.jsxs)("h4",{className:"font-bold text-foreground mb-4 flex items-center gap-2",children:[(0,t.jsx)(m.MessageCircle,{size:18,className:"text-green-500"}),"Bài học liên quan"]}),(0,t.jsx)("div",{className:"space-y-4",children:F.map(e=>(0,t.jsxs)(r.default,{href:`/kien-thuc-forex/${e.slug}`,className:"group flex gap-3",children:[(0,t.jsx)("div",{className:"w-20 h-14 rounded-lg overflow-hidden bg-secondary shrink-0",children:(0,t.jsx)("img",{src:e.featured_image||"https://placehold.co/80x56/1e293b/ffffff?text=Learn",alt:e.title,className:"w-full h-full object-cover group-hover:scale-110 transition-transform"})}),(0,t.jsx)("div",{className:"flex-1 min-w-0",children:(0,t.jsx)("h5",{className:"text-sm font-medium text-foreground line-clamp-2 group-hover:text-green-500 transition-colors",children:e.title})})]},e.id))})]}),(0,t.jsxs)("button",{onClick:()=>window.scrollTo({top:0,behavior:"smooth"}),className:"w-full flex items-center justify-center gap-2 py-3 bg-secondary hover:bg-slate-700 text-foreground font-medium rounded-xl transition-colors",children:[(0,t.jsx)(u.ChevronUp,{size:18}),"Lên đầu trang"]})]})})]})})]})}e.s(["default",()=>T],40337)}]);