(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,78917,e=>{"use strict";let t=(0,e.i(75254).default)("external-link",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);e.s(["ExternalLink",()=>t],78917)},63059,e=>{"use strict";let t=(0,e.i(75254).default)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);e.s(["ChevronRight",()=>t],63059)},98919,e=>{"use strict";let t=(0,e.i(75254).default)("shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);e.s(["Shield",()=>t],98919)},48256,e=>{"use strict";let t=(0,e.i(75254).default)("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);e.s(["Globe",()=>t],48256)},26707,e=>{"use strict";let t=(0,e.i(75254).default)("smartphone",[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]]);e.s(["Smartphone",()=>t],26707)},42942,e=>{"use strict";let t=[{id:1,rank:1,name:"Vantage",slug:"vantage",logo:"https://sanuytin.net/wp-content/uploads/2025/11/san-giao-dich-forex-vantage-co-uy-tin-khong.png",score:9.9,minDep:"$50",maxLev:"1:1000",license:"ASIC, FCA, CIMA",features:["Khớp lệnh siêu tốc","Raw Spread từ 0.0","Hỗ trợ người Việt"],reviewLink:"vantage",registerLink:"https://www.vantage-markets-apac.com/vi/open-live-account/?affid=NzI2ODQyNw==",foundedYear:"2009",headquarters:"Sydney, Australia",platforms:["MT4","MT5","ProTrader","App"],depositMethods:["Internet Banking","Visa/Master","USDT","Skrill"],pros:["Được cấp phép bởi các tổ chức uy tín hàng đầu (ASIC, FCA)","Tốc độ khớp lệnh cực nhanh, không re-quote","Phí giao dịch thấp, đặc biệt là tài khoản Raw ECN","Hỗ trợ nạp rút tiền nhanh chóng qua ngân hàng nội địa"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Yêu cầu tiền nạp tối thiểu $50 (cao hơn một số sàn khác)","Ít chương trình Bonus cho khách hàng cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Vantage
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Vantage</strong> (trước đ\xe2y l\xe0 Vantage FX) l\xe0 nh\xe0 m\xf4i giới đa t\xe0i sản to\xe0n cầu được th\xe0nh lập từ năm 2009, c\xf3 trụ sở ch\xednh tại Sydney, \xdac. 
                        Với hơn 15 năm hoạt động, Vantage đ\xe3 khẳng định vị thế l\xe0 "Thi\xean đường cho ECN Trader" nhờ hạ tầng c\xf4ng nghệ vượt trội.
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        S\xe0n kết nối trực tiếp với c\xe1c nh\xe0 cung cấp thanh khoản h\xe0ng đầu (Tier-1 Liquidity Providers) qua cầu nối quang học <span class="font-semibold text-foreground">oneZero™ MT4 Bridge</span>, 
                        đảm bảo tốc độ khớp lệnh si\xeau tốc (dưới 30ms) v\xe0 kh\xf4ng c\xf3 sự can thiệp của b\xe0n giao dịch (No Dealing Desk).
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p & Độ Uy T\xedn
                    </h3>
                    <p class="mb-3 text-muted-foreground">Vantage sở hữu hồ sơ ph\xe1p l\xfd cực kỳ "sạch" v\xe0 uy t\xedn với c\xe1c giấy ph\xe9p hạng A:</p>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">ASIC (\xdac)</span>
                            <span class="text-sm text-muted-foreground">GP số 428901 - Một trong những giấy ph\xe9p kh\xf3 đạt được nhất thế giới.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">FCA (Anh)</span>
                            <span class="text-sm text-muted-foreground">GP số 590299 - Bảo hiểm tiền gửi l\xean đến \xa385,000 cho kh\xe1ch h\xe0ng.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">CIMA (Cayman)</span>
                            <span class="text-sm text-muted-foreground">GP số 1383491 - Quản l\xfd hoạt động to\xe0n cầu với cơ chế linh hoạt.</span>
                        </li>
                    </ul>
                    <p class="text-sm text-muted-foreground italic">
                        *Tiền k\xfd quỹ của kh\xe1ch h\xe0ng được giữ trong t\xe0i khoản t\xe1ch biệt (Segregated Accounts) tại Ng\xe2n h\xe0ng Quốc gia \xdac (NAB), đảm bảo an to\xe0n tuyệt đối.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Điều Kiện Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Loại T\xe0i Khoản</th>
                                    <th class="p-3 text-left">Spread Từ</th>
                                    <th class="p-3 text-left">Hoa Hồng (2 chiều)</th>
                                    <th class="p-3 text-left">Nạp Tối Thiểu</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Standard STP</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-green-600">Kh\xf4ng ph\xed</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr class="bg-primary/5">
                                    <td class="p-3 font-medium">Raw ECN (Khuy\xean d\xf9ng)</td>
                                    <td class="p-3 font-bold text-primary">0.0 pips</td>
                                    <td class="p-3">$6.0</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Pro ECN</td>
                                    <td class="p-3">0.0 pips</td>
                                    <td class="p-3">$3.0</td>
                                    <td class="p-3">$10,000</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="mt-3 text-muted-foreground">
                        Với t\xe0i khoản <strong>Raw ECN</strong>, bạn sẽ được trải nghiệm spread V\xe0ng gần như bằng 0 trong phi\xean \xc2u v\xe0 Mỹ. Đ\xe2y l\xe0 điểm mạnh tuyệt đối của Vantage so với Exness hay XM.
                    </p>
                </div>
            </div>
        `},{id:3,rank:2,name:"XM",slug:"xm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xm-sanuytin.jpg",score:9.8,minDep:"$5",maxLev:"1:1000",license:"ASIC, CySEC, FSC",features:["Bonus $30 không cần nạp","Phí qua đêm thấp","Khớp lệnh nhanh"],reviewLink:"xm",registerLink:"https://affs.click/mG65j",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","XM App"],depositMethods:["Internet Banking","MoMo","Visa"],pros:["Chương trình Bonus thưởng nạp tiền hấp dẫn nhất","Không yêu cầu báo giá lại (Re-quotes)","Phí spread ổn định, không giãn mạnh"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Tài khoản Standard có spread hơi cao so với ECN","Giao diện web hơi cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tại Sao XM Được Y\xeau Th\xedch?
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>XM</strong> (XM Global) l\xe0 một trong những nh\xe0 m\xf4i giới lớn nhất thế giới với hơn <strong>10 triệu kh\xe1ch h\xe0ng</strong> từ 190 quốc gia. 
                        Thương hiệu XM gắn liền với sự "H\xe0o Ph\xf3ng" nhờ c\xe1c chương tr\xecnh khuyến m\xe3i khủng v\xe0 ch\xednh s\xe1ch kh\xf4ng b\xe1o gi\xe1 lại (No Re-quotes).
                    </p>
                    <div class="bg-card p-4 rounded-xl border border-border shadow-sm flex gap-4 items-center">
                        <div class="bg-green-500/10 p-3 rounded-full text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        </div>
                        <div>
                            <div class="font-bold text-foreground">Bonus $30 (Kh\xf4ng Cần Nạp)</div>
                            <div class="text-sm text-muted-foreground">Tặng ngay $30 v\xe0o t\xe0i khoản khi mở mới. L\xe3i r\xfat được, tiền thưởng kh\xf4ng r\xfat được.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> T\xe0i Khoản Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Đặc Điểm</th>
                                    <th class="p-3 text-left">Micro</th>
                                    <th class="p-3 text-left">Standard</th>
                                    <th class="p-3 text-left">Ultra Low</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Tiền nạp tối thiểu</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Spread từ</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-primary">0.6 pips</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Hoa hồng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Lot size</td>
                                    <td class="p-3">1,000 unit</td>
                                    <td class="p-3">100,000 unit</td>
                                    <td class="p-3">Chuẩn</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Ưu Đ\xe3i Độc Quyền
                    </h3>
                    <ul class="space-y-2">
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Thưởng nạp tiền 50% l\xean đến $500 v\xe0 20% l\xean đến $4,500.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Chương tr\xecnh kh\xe1ch h\xe0ng th\xe2n thiết (XM Loyalty) t\xedch điểm đổi tiền mặt.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Miễn ph\xed m\xe1y chủ ảo (VPS) cho t\xe0i khoản c\xf3 số dư > $500.</span>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:2,rank:3,name:"Exness",slug:"exness",logo:"https://sanuytin.net/wp-content/uploads/2025/10/exness-sanuytin.jpg",score:9.5,minDep:"$10",maxLev:"Vô cực",license:"FCA, CySEC, FSA",features:["Nạp rút tức thì","Spread cực thấp","Hỗ trợ tiếng Việt 24/7"],reviewLink:"exness",registerLink:"#",foundedYear:"2008",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","Exness Terminal"],depositMethods:["Internet Banking","VietQR","USDT","Visa/Master"],pros:["Nạp rút tiền diễn ra tức thì, kể cả cuối tuần","Đòn bẩy không giới hạn (Vô cực)","Spread trên cặp vàng và tiền tệ chính cực thấp","Đội ngũ hỗ trợ người Việt 24/7 nhiệt tình"],avgSpread:"0.6 pips",commission:"Không phí",cons:["Máy chủ đôi khi bị lag vào giờ tin mạnh","Spread có thể giãn nhẹ khi thị trường biến động cực đoan"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Exness
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Exness</strong> được cộng đồng trader Việt Nam mệnh danh l\xe0 "Vua thanh khoản". Th\xe0nh lập từ 2008, Exness hiện l\xe0 nh\xe0 m\xf4i giới c\xf3 khối lượng giao dịch lớn nhất thế giới (đạt hơn 4.000 tỷ USD/th\xe1ng v\xe0o năm 2024).
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        Điểm "ăn tiền" nhất của Exness ch\xednh l\xe0 cơ chế <strong>Nạp R\xfat Tức Th\xec (Instant Withdrawal)</strong>. Hệ thống xử l\xfd tự động 24/7 cho ph\xe9p tiền về t\xe0i khoản ng\xe2n h\xe0ng của bạn chỉ trong v\xe0i gi\xe2y, kể cả Thứ 7 v\xe0 Chủ Nhật.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p Hoạt Động
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">FCA (Vương Quốc Anh)</div>
                            <div class="text-xs text-muted-foreground">Giấy ph\xe9p uy t\xedn nhất ng\xe0nh t\xe0i ch\xednh, bảo vệ quyền lợi tối đa cho nh\xe0 đầu tư.</div>
                        </div>
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">CySEC (S\xedp)</div>
                            <div class="text-xs text-muted-foreground">Cho ph\xe9p hoạt động hợp ph\xe1p tr\xean to\xe0n ch\xe2u \xc2u.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> C\xe1c Loại T\xe0i Khoản
                    </h3>
                    <ul class="space-y-4">
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">1. Standard & Standard Cent</span>
                                <span class="bg-green-500/10 text-green-600 px-2 py-0.5 rounded text-xs font-bold">Phổ biến nhất</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Chỉ từ $1 nạp vốn. Ph\xf9 hợp cho người mới bắt đầu (Newbie). Spread ổn định từ 0.3 pips. <br>
                                <strong>Đ\xf2n bẩy: V\xf4 cực (1:Unlimited)</strong> - Duy nhất tr\xean thị trường.
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">2. Raw Spread</span>
                                <span class="bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded text-xs font-bold">Cho Scalper</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Spread cặp ch\xednh cố định ở <strong>0.0 pips</strong>. Ph\xed hoa hồng $7/lot. <br>
                                L\xfd tưởng cho c\xe1c chiến lược lướt s\xf3ng (Scalping) v\xe0 giao dịch thuật to\xe1n (EA).
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">3. Zero Account</span>
                                <span class="bg-purple-500/10 text-purple-600 px-2 py-0.5 rounded text-xs font-bold">Spread 0.0</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Cam kết Spread 0.0 pips trong 95% thời gian giao dịch cho 30 cặp tiền ch\xednh. Ph\xed hoa hồng từ $3.5/lot/chiều.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:4,rank:4,name:"XTB",slug:"xtb",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xtb-sanuytin.jpg",score:9.5,minDep:"$0",maxLev:"1:500",license:"FCA, CySEC, KNF",features:["Nền tảng xStation 5 xịn","Niêm yết chứng khoán","Miễn phí qua đêm vàng"],reviewLink:"xtb",registerLink:"#",foundedYear:"2002",headquarters:"Warsaw, Poland",platforms:["xStation 5","xStation Mobile"],depositMethods:["NganLuong","Visa","Skrill"],pros:["Nền tảng xStation 5 độc quyền cực kỳ mượt mà","Được niêm yết trên sàn chứng khoán (minh bạch tài chính)","Miễn phí phí qua đêm (Swap) cho lệnh Vàng và nhiều cặp tiền"],avgSpread:"0.8 pips",commission:"Không phí",cons:["Không hỗ trợ MT4/MT5 (có thể khó quen với người cũ)","Đòn bẩy tối đa chỉ 1:500"],longDescription:`
            <p class="mb-4"><strong>XTB</strong> l\xe0 một Fintech company thực thụ trong lĩnh vực Forex. Kh\xe1c với c\xe1c s\xe0n kh\xe1c d\xf9ng MT4, XTB ph\xe1t triển nền tảng xStation 5 đoạt nhiều giải thưởng, mang lại trải nghiệm giao dịch vượt trội.</p>
        `},{id:5,rank:5,name:"FBS",slug:"fbs",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fbs-sanuytin.png",score:9.3,minDep:"$1",maxLev:"1:3000",license:"CySEC, ASIC, FSC",features:["Nhiều loại tài khoản","Copy trade tốt","Nạp rút nhanh"],reviewLink:"fbs",registerLink:"#",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FBS Trader"],depositMethods:["Internet Banking","Visa","USDT"],pros:["Đòn bẩy cực cao lên tới 1:3000","Nhiều loại tài khoản phù hợp mọi trader (Cent, Micro, Standard)","Ứng dụng Copy Trade tốt"],avgSpread:"0.7 pips",commission:"Không phí",cons:["Spread tài khoản thường hơi cao","Giấy phép quốc tế chưa mạnh bằng top đầu"],longDescription:`
            <p class="mb-4"><strong>FBS</strong> l\xe0 lựa chọn phổ biến cho c\xe1c trader mới bắt đầu nhờ y\xeau cầu vốn thấp v\xe0 t\xe0i khoản Cent. S\xe0n c\xf3 mặt tại hơn 150 quốc gia v\xe0 nổi tiếng với c\xe1c hoạt động marketing s\xf4i nổi.</p>
        `},{id:6,rank:6,name:"HFM",slug:"hfm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/hfm-sanuytin.jpg",score:9.2,minDep:"$5",maxLev:"1:2000",license:"FCA, CySEC, FSA",features:["Bonus nạp tiền lớn","Nhiều công cụ GD","Bảo hiểm vốn"],reviewLink:"hfm",registerLink:"#",foundedYear:"2010",headquarters:"Larnaca, Cyprus",platforms:["MT4","MT5","HFM App"],depositMethods:["Bank Transfer","Crypto","Cards","MoMo"],pros:["Chương trình Bảo hiểm Trách nhiệm Dân sự lên đến 5.000.000 EUR","Tài khoản PAMM chất lượng cho nhà đầu tư","Công cụ phân tích độc quyền Premium Trader Tools","Nhiều loại tài khoản linh hoạt (Cent, Zero, Premium)"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Quy trình xác minh danh tính đôi khi hơi lâu (24h)","Không hỗ trợ PayPal cho khách hàng Việt Nam"],longDescription:`
            <p class="mb-4"><strong>HFM</strong> (trước đ\xe2y l\xe0 HotForex) l\xe0 một thương hiệu m\xf4i giới đa t\xe0i sản từng đoạt giải thưởng. Với hơn 2.5 triệu t\xe0i khoản thực đ\xe3 mở, HFM khẳng định vị thế l\xe0 một trong những s\xe0n giao dịch lớn nhất thế giới.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">An to\xe0n v\xe0 Bảo mật</h3>
            <p class="mb-4">HFM nổi bật với g\xf3i bảo hiểm l\xe1 chắn thị trường trị gi\xe1 5 triệu Euro, bảo vệ kh\xe1ch h\xe0ng khỏi c\xe1c lỗi sai s\xf3t, gian lận hoặc sơ suất c\xf3 thể dẫn đến thiệt hại về t\xe0i ch\xednh. Đ\xe2y l\xe0 điểm cộng cực lớn về uy t\xedn.</p>
        `},{id:7,rank:7,name:"FXTM",slug:"fxtm",logo:"https://sanuytin.net/wp-content/uploads/2025/11/fxtm-san-forex-uy-tin-2025.jpeg",score:9.1,minDep:"$10",maxLev:"1:2000",license:"FCA, CySEC",features:["Đào tạo tốt","Tài khoản ECN","Hỗ trợ nhiệt tình"],reviewLink:"fxtm",registerLink:"#",foundedYear:"2011",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FXTM Trader"],depositMethods:["Internet Banking","E-wallets","Visa/Master"],pros:["Tốc độ khớp lệnh ECN cực nhanh, trung bình vài mili giây","Nền tảng FXTM Invest (Copy Trade) rất phát triển","Kho tài liệu giáo dục và hội thảo online phong phú","Tách biệt vốn khách hàng tại các ngân hàng Tier-1"],avgSpread:"1.5 pips",commission:"Không phí",cons:["Phí rút tiền qua một số ví điện tử có thể cao","Giao diện web quản lý tài khoản hơi rối với người mới"],longDescription:`
            <p class="mb-4"><strong>FXTM</strong> (ForexTime) được biết đến l\xe0 nh\xe0 m\xf4i giới c\xf3 tốc độ tăng trưởng nhanh nhất thế giới. S\xe0n tập trung mạnh v\xe0o gi\xe1o dục v\xe0 c\xf4ng nghệ khớp lệnh ECN, mang lại trải nghiệm giao dịch chuy\xean nghiệp.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Gi\xe1o dục v\xe0 Đ\xe0o tạo</h3>
            <p class="mb-4">FXTM đầu tư rất mạnh v\xe0o mảng đ\xe0o tạo với h\xe0ng loạt Ebook, Video hướng dẫn v\xe0 c\xe1c buổi Webinar h\xe0ng tuần. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c trader mới muốn n\xe2ng cao kiến thức b\xe0i bản.</p>
        `},{id:8,rank:8,name:"FxPro",slug:"fxpro",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fxpro-sanuytin.jpg",score:8.9,minDep:"$100",maxLev:"1:500",license:"FCA, CySEC, SCB",features:["Thương hiệu toàn cầu","Không phí hoa hồng","Nhiều nền tảng"],reviewLink:"fxpro",registerLink:"#",foundedYear:"2006",headquarters:"London, UK",platforms:["cTrader","MT4","MT5","FxPro Edge"],depositMethods:["Bank","Visa","PayPal","Skrill"],pros:["Thương hiệu toàn cầu uy tín, nhà tài trợ đội đua McLaren F1","Nền tảng cTrader mạnh mẽ, hỗ trợ đo lường độ sâu thị trường (DOM)","Mô hình No Dealing Desk (NDD) minh bạch hoàn toàn","Ví FxPro Wallet giúp quản lý vốn an toàn, tách biệt rủi ro"],avgSpread:"1.2 pips",commission:"Không phí",cons:["Spread trên tài khoản MT4 không cạnh tranh bằng Exness hay Vantage","Quy trình mở tài khoản yêu cầu xác minh khá kỹ"],longDescription:`
            <p class="mb-4"><strong>FxPro</strong> l\xe0 "\xf4ng lớn" thực thụ trong ng\xe0nh Forex với trụ sở ch\xednh tại London. Hoạt động từ 2006, FxPro đ\xe3 phục vụ kh\xe1ch h\xe0ng tại hơn 170 quốc gia v\xe0 xử l\xfd h\xe0ng ngh\xecn lệnh mỗi gi\xe2y.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Nền tảng cTrader</h3>
            <p class="mb-4">FxPro l\xe0 một trong những broker cung cấp nền tảng cTrader tốt nhất hiện nay. cTrader cho ph\xe9p trader nh\xecn thấy độ s\xe2u thị trường (Market Depth) v\xe0 khớp lệnh VWAP (Volume Weighted Average Price), cực kỳ ph\xf9 hợp cho Scalping chuy\xean nghiệp.</p>
        `},{id:9,rank:9,name:"Tickmill",slug:"tickmill",logo:"https://sanuytin.net/wp-content/uploads/2025/10/tickmill-sanuytin.jpg",score:8.6,minDep:"$100",maxLev:"1:1000",license:"FCA, CySEC, FSA",features:["Spread thấp ổn định","Không phí hoa hồng","Execution nhanh"],reviewLink:"tickmill",registerLink:"#",foundedYear:"2014",headquarters:"Mahe, Seychelles",platforms:["MT4","MT5"],depositMethods:["Bank Transfer","Crypto","Neteller","Skrill"],pros:["Phí hoa hồng (Commission) thấp nhất thị trường: 2 đơn vị tiền tệ/lot","Chào đón mọi chiến lược giao dịch: Scalping, News Trading, EA","Không có phí ẩn, spread cực thấp trên tài khoản Pro","Giấy phép FCA Anh Quốc uy tín"],avgSpread:"0.0 pips",commission:"$2/lot",cons:["Ít sản phẩm giao dịch (chủ yếu là Forex, Vàng, Dầu, một số Index)","Không có tài khoản Cent (chỉ có Pro và Classic)"],longDescription:`
            <p class="mb-4"><strong>Tickmill</strong> l\xe0 thi\xean đường cho d\xe2n Scalping v\xe0 Algo Trading (Giao dịch thuật to\xe1n). S\xe0n nổi tiếng với điều kiện giao dịch "Raw" nhất: spread thấp, ph\xed hoa hồng cực rẻ v\xe0 tốc độ khớp lệnh tuyệt vời.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Chi ph\xed giao dịch</h3>
            <p class="mb-4">Nếu bạn quan t\xe2m đến chi ph\xed, Tickmill l\xe0 lựa chọn số 1. T\xe0i khoản Pro của họ c\xf3 spread từ 0.0 pips v\xe0 ph\xed hoa hồng chỉ 2 USD/lot/chiều, thấp hơn 30-40% so với mức trung b\xecnh ng\xe0nh (thường l\xe0 3.5 USD).</p>
        `},{id:10,rank:10,name:"Pepperstone",slug:"pepperstone",logo:"https://sanuytin.net/wp-content/uploads/2025/10/Pepperstone-sanuytin.jpg",score:8.3,minDep:"$0 (rec. $200)",maxLev:"1:500",license:"ASIC, FCA, SCB",features:["Khớp lệnh cực nhanh","Không Dealing Desk","Hỗ trợ cTrader"],reviewLink:"/pepperstone",registerLink:"#",foundedYear:"2010",headquarters:"Melbourne, Australia",platforms:["cTrader","MT4","MT5","TradingView"],depositMethods:["Internet Banking","Visa","PayPal"],pros:["Hỗ trợ kết nối trực tiếp với TradingView để giao dịch","Thanh khoản sâu từ 22 ngân hàng Tier-1","Dịch vụ chăm sóc khách hàng được đánh giá 5 sao","Khớp lệnh cực nhanh dưới 30ms"],avgSpread:"0.0 pips",commission:"$3.5/lot",cons:["Yêu cầu nạp tiền lần đầu $200 (hơi cao với sinh viên)","Không có nhiều chương trình Bonus như XM hay Exness"],longDescription:`
            <p class="mb-4"><strong>Pepperstone</strong> l\xe0 niềm tự h\xe0o của \xdac trong lĩnh vực Fintech. S\xe0n nổi tiếng với tốc độ, sự ổn định v\xe0 hỗ trợ c\xf4ng nghệ tận răng. Pepperstone l\xe0 một trong số \xedt broker cho ph\xe9p bạn giao dịch trực tiếp tr\xean biểu đồ TradingView.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">C\xf4ng nghệ ECN/STP</h3>
            <p class="mb-4">Pepperstone hoạt động theo m\xf4 h\xecnh No Dealing Desk thực thụ. Mọi lệnh của bạn được đẩy trực tiếp ra thị trường li\xean ng\xe2n h\xe0ng với độ trễ gần như bằng 0. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c hệ thống giao dịch tự động (EA).</p>
        `}];e.s(["brokers",0,t])},55777,e=>{"use strict";var t=e.i(43476),n=e.i(42942),s=e.i(98919),i=e.i(75254);let r=(0,i.default)("landmark",[["path",{d:"M10 18v-7",key:"wt116b"}],["path",{d:"M11.12 2.198a2 2 0 0 1 1.76.006l7.866 3.847c.476.233.31.949-.22.949H3.474c-.53 0-.695-.716-.22-.949z",key:"1m329m"}],["path",{d:"M14 18v-7",key:"vav6t3"}],["path",{d:"M18 18v-7",key:"aexdmj"}],["path",{d:"M3 22h18",key:"8prr45"}],["path",{d:"M6 18v-7",key:"1ivflk"}]]);var a=e.i(48256),o=e.i(26707);let h=(0,i.default)("credit-card",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]);var d=e.i(63059),c=e.i(78917),l=e.i(22016),p=e.i(71645);function x(){let[e,i]=(0,p.useState)(!1),[x,g]=(0,p.useState)(!0),m=(0,p.useRef)(null),u=()=>{if(m.current){let{scrollLeft:e,scrollWidth:t,clientWidth:n}=m.current;i(e>0),g(e<t-n-5)}};(0,p.useEffect)(()=>(u(),window.addEventListener("resize",u),()=>window.removeEventListener("resize",u)),[]);let b=[{label:"Điểm Đánh Giá",key:"score",icon:null},{label:"Giấy Phép",key:"license",icon:(0,t.jsx)(s.Shield,{size:16,className:"text-primary"})},{label:"Năm Thành Lập",key:"foundedYear",icon:(0,t.jsx)(r,{size:16,className:"text-blue-500"})},{label:"Trụ Sở Chính",key:"headquarters",icon:(0,t.jsx)(a.Globe,{size:16,className:"text-green-500"})},{label:"Nạp Tối Thiểu",key:"minDep",icon:null},{label:"Đòn Bẩy Tối Đa",key:"maxLev",icon:null},{label:"Spread Trung Bình",key:"avgSpread",icon:null},{label:"Hoa Hồng",key:"commission",icon:null},{label:"Nền Tảng",key:"platforms",icon:(0,t.jsx)(o.Smartphone,{size:16,className:"text-purple-500"})},{label:"Nạp Rút",key:"depositMethods",icon:(0,t.jsx)(h,{size:16,className:"text-orange-500"})}];return(0,t.jsxs)("div",{className:"relative border border-border rounded-xl bg-card shadow-sm overflow-hidden",children:[(0,t.jsx)("div",{className:`absolute top-0 bottom-0 left-[140px] md:left-[200px] w-8 bg-gradient-to-r from-background/50 to-transparent z-20 pointer-events-none transition-opacity ${e?"opacity-100":"opacity-0"}`}),(0,t.jsx)("div",{className:`absolute top-0 bottom-0 right-0 w-8 bg-gradient-to-l from-background/50 to-transparent z-20 pointer-events-none transition-opacity ${x?"opacity-100":"opacity-0"}`}),(0,t.jsx)("div",{ref:m,className:"overflow-x-auto scrollbar-hide pb-2",onScroll:u,children:(0,t.jsxs)("div",{className:"min-w-max",children:[(0,t.jsxs)("div",{className:"flex sticky top-0 z-30",children:[(0,t.jsx)("div",{className:"sticky left-0 bg-secondary/80 backdrop-blur-md border-b border-r border-border min-w-[140px] md:min-w-[200px] p-4 flex items-center font-bold text-foreground",children:"Tiêu Chí So Sánh"}),n.brokers.map(e=>(0,t.jsxs)("div",{className:"min-w-[160px] md:min-w-[200px] border-b border-r border-border bg-card p-4 flex flex-col items-center gap-3 text-center transition-colors hover:bg-secondary/20",children:[(0,t.jsx)("div",{className:"w-16 h-16 bg-white rounded-lg border border-border/50 p-1 shadow-sm flex items-center justify-center",children:(0,t.jsx)("img",{src:e.logo,alt:e.name,className:"w-full h-full object-contain"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"font-bold text-base md:text-lg",children:e.name}),(0,t.jsxs)("div",{className:"text-xs text-muted-foreground font-semibold flex items-center justify-center gap-1",children:[(0,t.jsx)("span",{className:"text-primary",children:e.score}),"/10"]})]}),(0,t.jsxs)("a",{href:e.registerLink,target:"_blank",rel:"nofollow noreferrer",className:"text-xs font-bold bg-primary text-white py-1.5 px-3 rounded-full hover:bg-primary/90 transition-none w-full flex items-center justify-center gap-1",children:["Mở Tài Khoản ",(0,t.jsx)(c.ExternalLink,{size:10})]})]},e.id))]}),(0,t.jsxs)("div",{className:"divide-y divide-border",children:[b.map((e,s)=>(0,t.jsxs)("div",{className:`flex transition-colors hover:bg-secondary/10 ${s%2==0?"bg-background":"bg-card"}`,children:[(0,t.jsxs)("div",{className:"sticky left-0 bg-background/95 backdrop-blur-sm border-r border-border min-w-[140px] md:min-w-[200px] p-3 md:p-4 text-sm font-semibold text-muted-foreground flex items-center gap-2 z-10",children:[e.icon,(0,t.jsx)("span",{className:"truncate",children:e.label})]}),n.brokers.map(n=>{let s,i=n[e.key];s=Array.isArray(i)?i.slice(0,2).join(", ")+(i.length>2?"...":""):i;let r="text-sm text-foreground";return"score"===e.key&&(r="font-bold text-primary text-base"),"avgSpread"===e.key&&0===parseFloat(String(i))&&(r="font-bold text-green-600 bg-green-500/10 px-2 py-0.5 rounded"),"avgSpread"===e.key&&parseFloat(String(i))>0&&(r="font-bold text-foreground"),(0,t.jsx)("div",{className:"min-w-[160px] md:min-w-[200px] border-r border-border p-3 md:p-4 flex items-center justify-center text-center",children:(0,t.jsxs)("span",{className:r,children:[s,"avgSpread"===e.key&&"0.0 pips"===i&&(0,t.jsx)("span",{className:"block text-[10px] font-normal text-muted-foreground",children:"(Raw)"})]})},`${n.id}-${e.key}`)})]},e.key)),(0,t.jsxs)("div",{className:"flex bg-secondary/5",children:[(0,t.jsx)("div",{className:"sticky left-0 bg-secondary/80 backdrop-blur-sm border-r border-border min-w-[140px] md:min-w-[200px] p-4 font-semibold text-muted-foreground flex items-center z-10",children:"Chi Tiết"}),n.brokers.map(e=>(0,t.jsx)("div",{className:"min-w-[160px] md:min-w-[200px] border-r border-border p-4 flex items-center justify-center",children:(0,t.jsxs)(l.default,{href:`/${e.slug}`,className:"text-primary hover:underline text-sm font-medium flex items-center gap-1",children:["Xem Review ",(0,t.jsx)(d.ChevronRight,{size:14})]})},`link-${e.id}`))]})]})]})})]})}e.s(["default",()=>x],55777)}]);