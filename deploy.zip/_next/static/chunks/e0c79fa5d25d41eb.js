(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,55436,t=>{"use strict";let e=(0,t.i(75254).default)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);t.s(["Search",()=>e],55436)},7233,t=>{"use strict";let e=(0,t.i(75254).default)("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);t.s(["Plus",()=>e],7233)},87316,t=>{"use strict";let e=(0,t.i(75254).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);t.s(["Calendar",()=>e],87316)},72520,t=>{"use strict";let e=(0,t.i(75254).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);t.s(["ArrowRight",()=>e],72520)},64659,t=>{"use strict";let e=(0,t.i(75254).default)("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);t.s(["ChevronDown",()=>e],64659)},55900,t=>{"use strict";let e=(0,t.i(75254).default)("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);t.s(["ChevronUp",()=>e],55900)},25652,t=>{"use strict";let e=(0,t.i(75254).default)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]);t.s(["TrendingUp",()=>e],25652)},83086,t=>{"use strict";let e=(0,t.i(75254).default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]);t.s(["Sparkles",()=>e],83086)},42942,t=>{"use strict";let e=[{id:1,rank:1,name:"Vantage",slug:"vantage",logo:"https://sanuytin.net/wp-content/uploads/2025/11/san-giao-dich-forex-vantage-co-uy-tin-khong.png",score:9.9,minDep:"$50",maxLev:"1:1000",license:"ASIC, FCA, CIMA",features:["Khớp lệnh siêu tốc","Raw Spread từ 0.0","Hỗ trợ người Việt"],reviewLink:"vantage",registerLink:"https://www.vantage-markets-apac.com/vi/open-live-account/?affid=NzI2ODQyNw==",foundedYear:"2009",headquarters:"Sydney, Australia",platforms:["MT4","MT5","ProTrader","App"],depositMethods:["Internet Banking","Visa/Master","USDT","Skrill"],pros:["Được cấp phép bởi các tổ chức uy tín hàng đầu (ASIC, FCA)","Tốc độ khớp lệnh cực nhanh, không re-quote","Phí giao dịch thấp, đặc biệt là tài khoản Raw ECN","Hỗ trợ nạp rút tiền nhanh chóng qua ngân hàng nội địa"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Yêu cầu tiền nạp tối thiểu $50 (cao hơn một số sàn khác)","Ít chương trình Bonus cho khách hàng cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Vantage
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Vantage</strong> (trước đ\xe2y l\xe0 Vantage FX) l\xe0 nh\xe0 m\xf4i giới đa t\xe0i sản to\xe0n cầu được th\xe0nh lập từ năm 2009, c\xf3 trụ sở ch\xednh tại Sydney, \xdac. 
                        Với hơn 15 năm hoạt động, Vantage đ\xe3 khẳng định vị thế l\xe0 "Thi\xean đường cho ECN Trader" nhờ hạ tầng c\xf4ng nghệ vượt trội.
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        S\xe0n kết nối trực tiếp với c\xe1c nh\xe0 cung cấp thanh khoản h\xe0ng đầu (Tier-1 Liquidity Providers) qua cầu nối quang học <span class="font-semibold text-foreground">oneZero™ MT4 Bridge</span>, 
                        đảm bảo tốc độ khớp lệnh si\xeau tốc (dưới 30ms) v\xe0 kh\xf4ng c\xf3 sự can thiệp của b\xe0n giao dịch (No Dealing Desk).
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p & Độ Uy T\xedn
                    </h3>
                    <p class="mb-3 text-muted-foreground">Vantage sở hữu hồ sơ ph\xe1p l\xfd cực kỳ "sạch" v\xe0 uy t\xedn với c\xe1c giấy ph\xe9p hạng A:</p>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">ASIC (\xdac)</span>
                            <span class="text-sm text-muted-foreground">GP số 428901 - Một trong những giấy ph\xe9p kh\xf3 đạt được nhất thế giới.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">FCA (Anh)</span>
                            <span class="text-sm text-muted-foreground">GP số 590299 - Bảo hiểm tiền gửi l\xean đến \xa385,000 cho kh\xe1ch h\xe0ng.</span>
                        </li>
                        <li class="flex items-start gap-2 bg-secondary/30 p-3 rounded-lg border border-border/50">
                            <span class="font-bold text-primary">CIMA (Cayman)</span>
                            <span class="text-sm text-muted-foreground">GP số 1383491 - Quản l\xfd hoạt động to\xe0n cầu với cơ chế linh hoạt.</span>
                        </li>
                    </ul>
                    <p class="text-sm text-muted-foreground italic">
                        *Tiền k\xfd quỹ của kh\xe1ch h\xe0ng được giữ trong t\xe0i khoản t\xe1ch biệt (Segregated Accounts) tại Ng\xe2n h\xe0ng Quốc gia \xdac (NAB), đảm bảo an to\xe0n tuyệt đối.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Điều Kiện Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Loại T\xe0i Khoản</th>
                                    <th class="p-3 text-left">Spread Từ</th>
                                    <th class="p-3 text-left">Hoa Hồng (2 chiều)</th>
                                    <th class="p-3 text-left">Nạp Tối Thiểu</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Standard STP</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-green-600">Kh\xf4ng ph\xed</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr class="bg-primary/5">
                                    <td class="p-3 font-medium">Raw ECN (Khuy\xean d\xf9ng)</td>
                                    <td class="p-3 font-bold text-primary">0.0 pips</td>
                                    <td class="p-3">$6.0</td>
                                    <td class="p-3">$50</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Pro ECN</td>
                                    <td class="p-3">0.0 pips</td>
                                    <td class="p-3">$3.0</td>
                                    <td class="p-3">$10,000</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="mt-3 text-muted-foreground">
                        Với t\xe0i khoản <strong>Raw ECN</strong>, bạn sẽ được trải nghiệm spread V\xe0ng gần như bằng 0 trong phi\xean \xc2u v\xe0 Mỹ. Đ\xe2y l\xe0 điểm mạnh tuyệt đối của Vantage so với Exness hay XM.
                    </p>
                </div>
            </div>
        `},{id:3,rank:2,name:"XM",slug:"xm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xm-sanuytin.jpg",score:9.8,minDep:"$5",maxLev:"1:1000",license:"ASIC, CySEC, FSC",features:["Bonus $30 không cần nạp","Phí qua đêm thấp","Khớp lệnh nhanh"],reviewLink:"xm",registerLink:"https://affs.click/mG65j",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","XM App"],depositMethods:["Internet Banking","MoMo","Visa"],pros:["Chương trình Bonus thưởng nạp tiền hấp dẫn nhất","Không yêu cầu báo giá lại (Re-quotes)","Phí spread ổn định, không giãn mạnh"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Tài khoản Standard có spread hơi cao so với ECN","Giao diện web hơi cũ"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tại Sao XM Được Y\xeau Th\xedch?
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>XM</strong> (XM Global) l\xe0 một trong những nh\xe0 m\xf4i giới lớn nhất thế giới với hơn <strong>10 triệu kh\xe1ch h\xe0ng</strong> từ 190 quốc gia. 
                        Thương hiệu XM gắn liền với sự "H\xe0o Ph\xf3ng" nhờ c\xe1c chương tr\xecnh khuyến m\xe3i khủng v\xe0 ch\xednh s\xe1ch kh\xf4ng b\xe1o gi\xe1 lại (No Re-quotes).
                    </p>
                    <div class="bg-card p-4 rounded-xl border border-border shadow-sm flex gap-4 items-center">
                        <div class="bg-green-500/10 p-3 rounded-full text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        </div>
                        <div>
                            <div class="font-bold text-foreground">Bonus $30 (Kh\xf4ng Cần Nạp)</div>
                            <div class="text-sm text-muted-foreground">Tặng ngay $30 v\xe0o t\xe0i khoản khi mở mới. L\xe3i r\xfat được, tiền thưởng kh\xf4ng r\xfat được.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> T\xe0i Khoản Giao Dịch
                    </h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm rounded-lg overflow-hidden border border-border/50">
                            <thead class="bg-secondary/50 text-foreground">
                                <tr>
                                    <th class="p-3 text-left">Đặc Điểm</th>
                                    <th class="p-3 text-left">Micro</th>
                                    <th class="p-3 text-left">Standard</th>
                                    <th class="p-3 text-left">Ultra Low</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border/50">
                                <tr>
                                    <td class="p-3 font-medium">Tiền nạp tối thiểu</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                    <td class="p-3">$5</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Spread từ</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3">1.0 pips</td>
                                    <td class="p-3 font-bold text-primary">0.6 pips</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Hoa hồng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                    <td class="p-3 text-green-600 font-bold">Kh\xf4ng</td>
                                </tr>
                                <tr>
                                    <td class="p-3 font-medium">Lot size</td>
                                    <td class="p-3">1,000 unit</td>
                                    <td class="p-3">100,000 unit</td>
                                    <td class="p-3">Chuẩn</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> Ưu Đ\xe3i Độc Quyền
                    </h3>
                    <ul class="space-y-2">
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Thưởng nạp tiền 50% l\xean đến $500 v\xe0 20% l\xean đến $4,500.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Chương tr\xecnh kh\xe1ch h\xe0ng th\xe2n thiết (XM Loyalty) t\xedch điểm đổi tiền mặt.</span>
                        </li>
                        <li class="flex items-start gap-2">
                            <span class="text-primary font-bold">✓</span>
                            <span class="text-muted-foreground">Miễn ph\xed m\xe1y chủ ảo (VPS) cho t\xe0i khoản c\xf3 số dư > $500.</span>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:2,rank:3,name:"Exness",slug:"exness",logo:"https://sanuytin.net/wp-content/uploads/2025/10/exness-sanuytin.jpg",score:9.5,minDep:"$10",maxLev:"Vô cực",license:"FCA, CySEC, FSA",features:["Nạp rút tức thì","Spread cực thấp","Hỗ trợ tiếng Việt 24/7"],reviewLink:"exness",registerLink:"#",foundedYear:"2008",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","Exness Terminal"],depositMethods:["Internet Banking","VietQR","USDT","Visa/Master"],pros:["Nạp rút tiền diễn ra tức thì, kể cả cuối tuần","Đòn bẩy không giới hạn (Vô cực)","Spread trên cặp vàng và tiền tệ chính cực thấp","Đội ngũ hỗ trợ người Việt 24/7 nhiệt tình"],avgSpread:"0.6 pips",commission:"Không phí",cons:["Máy chủ đôi khi bị lag vào giờ tin mạnh","Spread có thể giãn nhẹ khi thị trường biến động cực đoan"],longDescription:`
            <div class="space-y-6">
                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">01.</span> Tổng Quan Về Exness
                    </h3>
                    <p class="mb-3 text-muted-foreground leading-relaxed">
                        <strong>Exness</strong> được cộng đồng trader Việt Nam mệnh danh l\xe0 "Vua thanh khoản". Th\xe0nh lập từ 2008, Exness hiện l\xe0 nh\xe0 m\xf4i giới c\xf3 khối lượng giao dịch lớn nhất thế giới (đạt hơn 4.000 tỷ USD/th\xe1ng v\xe0o năm 2024).
                    </p>
                    <p class="text-muted-foreground leading-relaxed">
                        Điểm "ăn tiền" nhất của Exness ch\xednh l\xe0 cơ chế <strong>Nạp R\xfat Tức Th\xec (Instant Withdrawal)</strong>. Hệ thống xử l\xfd tự động 24/7 cho ph\xe9p tiền về t\xe0i khoản ng\xe2n h\xe0ng của bạn chỉ trong v\xe0i gi\xe2y, kể cả Thứ 7 v\xe0 Chủ Nhật.
                    </p>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">02.</span> Giấy Ph\xe9p Hoạt Động
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">FCA (Vương Quốc Anh)</div>
                            <div class="text-xs text-muted-foreground">Giấy ph\xe9p uy t\xedn nhất ng\xe0nh t\xe0i ch\xednh, bảo vệ quyền lợi tối đa cho nh\xe0 đầu tư.</div>
                        </div>
                        <div class="bg-card p-4 rounded-xl border border-border shadow-sm">
                            <div class="font-bold text-primary mb-1">CySEC (S\xedp)</div>
                            <div class="text-xs text-muted-foreground">Cho ph\xe9p hoạt động hợp ph\xe1p tr\xean to\xe0n ch\xe2u \xc2u.</div>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold text-foreground flex items-center gap-2 mb-3">
                        <span class="text-primary">03.</span> C\xe1c Loại T\xe0i Khoản
                    </h3>
                    <ul class="space-y-4">
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">1. Standard & Standard Cent</span>
                                <span class="bg-green-500/10 text-green-600 px-2 py-0.5 rounded text-xs font-bold">Phổ biến nhất</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Chỉ từ $1 nạp vốn. Ph\xf9 hợp cho người mới bắt đầu (Newbie). Spread ổn định từ 0.3 pips. <br>
                                <strong>Đ\xf2n bẩy: V\xf4 cực (1:Unlimited)</strong> - Duy nhất tr\xean thị trường.
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">2. Raw Spread</span>
                                <span class="bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded text-xs font-bold">Cho Scalper</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Spread cặp ch\xednh cố định ở <strong>0.0 pips</strong>. Ph\xed hoa hồng $7/lot. <br>
                                L\xfd tưởng cho c\xe1c chiến lược lướt s\xf3ng (Scalping) v\xe0 giao dịch thuật to\xe1n (EA).
                            </p>
                        </li>
                        <li class="bg-secondary/30 p-4 rounded-xl border border-border/50">
                            <div class="flex justify-between items-center mb-2">
                                <span class="font-bold text-foreground">3. Zero Account</span>
                                <span class="bg-purple-500/10 text-purple-600 px-2 py-0.5 rounded text-xs font-bold">Spread 0.0</span>
                            </div>
                            <p class="text-sm text-muted-foreground">
                                Cam kết Spread 0.0 pips trong 95% thời gian giao dịch cho 30 cặp tiền ch\xednh. Ph\xed hoa hồng từ $3.5/lot/chiều.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        `},{id:4,rank:4,name:"XTB",slug:"xtb",logo:"https://sanuytin.net/wp-content/uploads/2025/10/xtb-sanuytin.jpg",score:9.5,minDep:"$0",maxLev:"1:500",license:"FCA, CySEC, KNF",features:["Nền tảng xStation 5 xịn","Niêm yết chứng khoán","Miễn phí qua đêm vàng"],reviewLink:"xtb",registerLink:"#",foundedYear:"2002",headquarters:"Warsaw, Poland",platforms:["xStation 5","xStation Mobile"],depositMethods:["NganLuong","Visa","Skrill"],pros:["Nền tảng xStation 5 độc quyền cực kỳ mượt mà","Được niêm yết trên sàn chứng khoán (minh bạch tài chính)","Miễn phí phí qua đêm (Swap) cho lệnh Vàng và nhiều cặp tiền"],avgSpread:"0.8 pips",commission:"Không phí",cons:["Không hỗ trợ MT4/MT5 (có thể khó quen với người cũ)","Đòn bẩy tối đa chỉ 1:500"],longDescription:`
            <p class="mb-4"><strong>XTB</strong> l\xe0 một Fintech company thực thụ trong lĩnh vực Forex. Kh\xe1c với c\xe1c s\xe0n kh\xe1c d\xf9ng MT4, XTB ph\xe1t triển nền tảng xStation 5 đoạt nhiều giải thưởng, mang lại trải nghiệm giao dịch vượt trội.</p>
        `},{id:5,rank:5,name:"FBS",slug:"fbs",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fbs-sanuytin.png",score:9.3,minDep:"$1",maxLev:"1:3000",license:"CySEC, ASIC, FSC",features:["Nhiều loại tài khoản","Copy trade tốt","Nạp rút nhanh"],reviewLink:"fbs",registerLink:"#",foundedYear:"2009",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FBS Trader"],depositMethods:["Internet Banking","Visa","USDT"],pros:["Đòn bẩy cực cao lên tới 1:3000","Nhiều loại tài khoản phù hợp mọi trader (Cent, Micro, Standard)","Ứng dụng Copy Trade tốt"],avgSpread:"0.7 pips",commission:"Không phí",cons:["Spread tài khoản thường hơi cao","Giấy phép quốc tế chưa mạnh bằng top đầu"],longDescription:`
            <p class="mb-4"><strong>FBS</strong> l\xe0 lựa chọn phổ biến cho c\xe1c trader mới bắt đầu nhờ y\xeau cầu vốn thấp v\xe0 t\xe0i khoản Cent. S\xe0n c\xf3 mặt tại hơn 150 quốc gia v\xe0 nổi tiếng với c\xe1c hoạt động marketing s\xf4i nổi.</p>
        `},{id:6,rank:6,name:"HFM",slug:"hfm",logo:"https://sanuytin.net/wp-content/uploads/2025/10/hfm-sanuytin.jpg",score:9.2,minDep:"$5",maxLev:"1:2000",license:"FCA, CySEC, FSA",features:["Bonus nạp tiền lớn","Nhiều công cụ GD","Bảo hiểm vốn"],reviewLink:"hfm",registerLink:"#",foundedYear:"2010",headquarters:"Larnaca, Cyprus",platforms:["MT4","MT5","HFM App"],depositMethods:["Bank Transfer","Crypto","Cards","MoMo"],pros:["Chương trình Bảo hiểm Trách nhiệm Dân sự lên đến 5.000.000 EUR","Tài khoản PAMM chất lượng cho nhà đầu tư","Công cụ phân tích độc quyền Premium Trader Tools","Nhiều loại tài khoản linh hoạt (Cent, Zero, Premium)"],avgSpread:"1.0 pips",commission:"Không phí",cons:["Quy trình xác minh danh tính đôi khi hơi lâu (24h)","Không hỗ trợ PayPal cho khách hàng Việt Nam"],longDescription:`
            <p class="mb-4"><strong>HFM</strong> (trước đ\xe2y l\xe0 HotForex) l\xe0 một thương hiệu m\xf4i giới đa t\xe0i sản từng đoạt giải thưởng. Với hơn 2.5 triệu t\xe0i khoản thực đ\xe3 mở, HFM khẳng định vị thế l\xe0 một trong những s\xe0n giao dịch lớn nhất thế giới.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">An to\xe0n v\xe0 Bảo mật</h3>
            <p class="mb-4">HFM nổi bật với g\xf3i bảo hiểm l\xe1 chắn thị trường trị gi\xe1 5 triệu Euro, bảo vệ kh\xe1ch h\xe0ng khỏi c\xe1c lỗi sai s\xf3t, gian lận hoặc sơ suất c\xf3 thể dẫn đến thiệt hại về t\xe0i ch\xednh. Đ\xe2y l\xe0 điểm cộng cực lớn về uy t\xedn.</p>
        `},{id:7,rank:7,name:"FXTM",slug:"fxtm",logo:"https://sanuytin.net/wp-content/uploads/2025/11/fxtm-san-forex-uy-tin-2025.jpeg",score:9.1,minDep:"$10",maxLev:"1:2000",license:"FCA, CySEC",features:["Đào tạo tốt","Tài khoản ECN","Hỗ trợ nhiệt tình"],reviewLink:"fxtm",registerLink:"#",foundedYear:"2011",headquarters:"Limassol, Cyprus",platforms:["MT4","MT5","FXTM Trader"],depositMethods:["Internet Banking","E-wallets","Visa/Master"],pros:["Tốc độ khớp lệnh ECN cực nhanh, trung bình vài mili giây","Nền tảng FXTM Invest (Copy Trade) rất phát triển","Kho tài liệu giáo dục và hội thảo online phong phú","Tách biệt vốn khách hàng tại các ngân hàng Tier-1"],avgSpread:"1.5 pips",commission:"Không phí",cons:["Phí rút tiền qua một số ví điện tử có thể cao","Giao diện web quản lý tài khoản hơi rối với người mới"],longDescription:`
            <p class="mb-4"><strong>FXTM</strong> (ForexTime) được biết đến l\xe0 nh\xe0 m\xf4i giới c\xf3 tốc độ tăng trưởng nhanh nhất thế giới. S\xe0n tập trung mạnh v\xe0o gi\xe1o dục v\xe0 c\xf4ng nghệ khớp lệnh ECN, mang lại trải nghiệm giao dịch chuy\xean nghiệp.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Gi\xe1o dục v\xe0 Đ\xe0o tạo</h3>
            <p class="mb-4">FXTM đầu tư rất mạnh v\xe0o mảng đ\xe0o tạo với h\xe0ng loạt Ebook, Video hướng dẫn v\xe0 c\xe1c buổi Webinar h\xe0ng tuần. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c trader mới muốn n\xe2ng cao kiến thức b\xe0i bản.</p>
        `},{id:8,rank:8,name:"FxPro",slug:"fxpro",logo:"https://sanuytin.net/wp-content/uploads/2025/10/fxpro-sanuytin.jpg",score:8.9,minDep:"$100",maxLev:"1:500",license:"FCA, CySEC, SCB",features:["Thương hiệu toàn cầu","Không phí hoa hồng","Nhiều nền tảng"],reviewLink:"fxpro",registerLink:"#",foundedYear:"2006",headquarters:"London, UK",platforms:["cTrader","MT4","MT5","FxPro Edge"],depositMethods:["Bank","Visa","PayPal","Skrill"],pros:["Thương hiệu toàn cầu uy tín, nhà tài trợ đội đua McLaren F1","Nền tảng cTrader mạnh mẽ, hỗ trợ đo lường độ sâu thị trường (DOM)","Mô hình No Dealing Desk (NDD) minh bạch hoàn toàn","Ví FxPro Wallet giúp quản lý vốn an toàn, tách biệt rủi ro"],avgSpread:"1.2 pips",commission:"Không phí",cons:["Spread trên tài khoản MT4 không cạnh tranh bằng Exness hay Vantage","Quy trình mở tài khoản yêu cầu xác minh khá kỹ"],longDescription:`
            <p class="mb-4"><strong>FxPro</strong> l\xe0 "\xf4ng lớn" thực thụ trong ng\xe0nh Forex với trụ sở ch\xednh tại London. Hoạt động từ 2006, FxPro đ\xe3 phục vụ kh\xe1ch h\xe0ng tại hơn 170 quốc gia v\xe0 xử l\xfd h\xe0ng ngh\xecn lệnh mỗi gi\xe2y.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Nền tảng cTrader</h3>
            <p class="mb-4">FxPro l\xe0 một trong những broker cung cấp nền tảng cTrader tốt nhất hiện nay. cTrader cho ph\xe9p trader nh\xecn thấy độ s\xe2u thị trường (Market Depth) v\xe0 khớp lệnh VWAP (Volume Weighted Average Price), cực kỳ ph\xf9 hợp cho Scalping chuy\xean nghiệp.</p>
        `},{id:9,rank:9,name:"Tickmill",slug:"tickmill",logo:"https://sanuytin.net/wp-content/uploads/2025/10/tickmill-sanuytin.jpg",score:8.6,minDep:"$100",maxLev:"1:1000",license:"FCA, CySEC, FSA",features:["Spread thấp ổn định","Không phí hoa hồng","Execution nhanh"],reviewLink:"tickmill",registerLink:"#",foundedYear:"2014",headquarters:"Mahe, Seychelles",platforms:["MT4","MT5"],depositMethods:["Bank Transfer","Crypto","Neteller","Skrill"],pros:["Phí hoa hồng (Commission) thấp nhất thị trường: 2 đơn vị tiền tệ/lot","Chào đón mọi chiến lược giao dịch: Scalping, News Trading, EA","Không có phí ẩn, spread cực thấp trên tài khoản Pro","Giấy phép FCA Anh Quốc uy tín"],avgSpread:"0.0 pips",commission:"$2/lot",cons:["Ít sản phẩm giao dịch (chủ yếu là Forex, Vàng, Dầu, một số Index)","Không có tài khoản Cent (chỉ có Pro và Classic)"],longDescription:`
            <p class="mb-4"><strong>Tickmill</strong> l\xe0 thi\xean đường cho d\xe2n Scalping v\xe0 Algo Trading (Giao dịch thuật to\xe1n). S\xe0n nổi tiếng với điều kiện giao dịch "Raw" nhất: spread thấp, ph\xed hoa hồng cực rẻ v\xe0 tốc độ khớp lệnh tuyệt vời.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">Chi ph\xed giao dịch</h3>
            <p class="mb-4">Nếu bạn quan t\xe2m đến chi ph\xed, Tickmill l\xe0 lựa chọn số 1. T\xe0i khoản Pro của họ c\xf3 spread từ 0.0 pips v\xe0 ph\xed hoa hồng chỉ 2 USD/lot/chiều, thấp hơn 30-40% so với mức trung b\xecnh ng\xe0nh (thường l\xe0 3.5 USD).</p>
        `},{id:10,rank:10,name:"Pepperstone",slug:"pepperstone",logo:"https://sanuytin.net/wp-content/uploads/2025/10/Pepperstone-sanuytin.jpg",score:8.3,minDep:"$0 (rec. $200)",maxLev:"1:500",license:"ASIC, FCA, SCB",features:["Khớp lệnh cực nhanh","Không Dealing Desk","Hỗ trợ cTrader"],reviewLink:"/pepperstone",registerLink:"#",foundedYear:"2010",headquarters:"Melbourne, Australia",platforms:["cTrader","MT4","MT5","TradingView"],depositMethods:["Internet Banking","Visa","PayPal"],pros:["Hỗ trợ kết nối trực tiếp với TradingView để giao dịch","Thanh khoản sâu từ 22 ngân hàng Tier-1","Dịch vụ chăm sóc khách hàng được đánh giá 5 sao","Khớp lệnh cực nhanh dưới 30ms"],avgSpread:"0.0 pips",commission:"$3.5/lot",cons:["Yêu cầu nạp tiền lần đầu $200 (hơi cao với sinh viên)","Không có nhiều chương trình Bonus như XM hay Exness"],longDescription:`
            <p class="mb-4"><strong>Pepperstone</strong> l\xe0 niềm tự h\xe0o của \xdac trong lĩnh vực Fintech. S\xe0n nổi tiếng với tốc độ, sự ổn định v\xe0 hỗ trợ c\xf4ng nghệ tận răng. Pepperstone l\xe0 một trong số \xedt broker cho ph\xe9p bạn giao dịch trực tiếp tr\xean biểu đồ TradingView.</p>
            <h3 class="text-xl font-bold mb-2 text-foreground">C\xf4ng nghệ ECN/STP</h3>
            <p class="mb-4">Pepperstone hoạt động theo m\xf4 h\xecnh No Dealing Desk thực thụ. Mọi lệnh của bạn được đẩy trực tiếp ra thị trường li\xean ng\xe2n h\xe0ng với độ trễ gần như bằng 0. Đ\xe2y l\xe0 m\xf4i trường l\xfd tưởng cho c\xe1c hệ thống giao dịch tự động (EA).</p>
        `}];t.s(["brokers",0,e])},15057,t=>{"use strict";let e=(0,t.i(75254).default)("arrow-up-right",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);t.s(["ArrowUpRight",()=>e],15057)},70273,t=>{"use strict";let e=(0,t.i(75254).default)("star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]]);t.s(["Star",()=>e],70273)},79334,t=>{"use strict";let e=(0,t.i(75254).default)("newspaper",[["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",key:"39pd36"}],["rect",{width:"8",height:"4",x:"10",y:"6",rx:"1",key:"aywv1n"}]]);t.s(["Newspaper",()=>e],79334)},71930,t=>{"use strict";let e=(0,t.i(75254).default)("bookmark",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]]);t.s(["Bookmark",()=>e],71930)},99023,t=>{"use strict";let e=(0,t.i(75254).default)("minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);t.s(["Minus",()=>e],99023)},23287,t=>{"use strict";let e=(0,t.i(75254).default)("circle-check",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);t.s(["default",()=>e])},79623,t=>{"use strict";var e=t.i(43476),n=t.i(22016),s=t.i(72520),i=t.i(87316),a=t.i(71930),r=t.i(79334),h=t.i(71645),o=t.i(7471);function c(){let[t,c]=(0,h.useState)([]),[d,l]=(0,h.useState)(!0);(0,h.useEffect)(()=>{!async function(){c((await (0,o.getPostsByCategory)("tin-tuc")).slice(0,3)),l(!1)}()},[]);let g=t.length>0?t:[{id:1,slug:"gia-vang-pha-dinh-2026",title:"Giá Vàng (XAU/USD) tiếp tục phá đỉnh lịch sử 2026",excerpt:"Căng thẳng địa chính trị leo thang khiến nhu cầu trú ẩn an toàn vào vàng tăng mạnh.",published_at:"2026-01-27",category:"Thị Trường",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/gia-vang-tang-manh.jpg"},{id:2,slug:"fed-giu-nguyen-lai-suat",title:"FED giữ nguyên lãi suất trong kỳ họp tháng 1",excerpt:"Cục dự trữ liên bang Mỹ quyết định giữ nguyên lãi suất, gây áp lực lên đồng USD.",published_at:"2026-01-26",category:"Kinh Tế",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/fed-lai-suat.jpg"},{id:3,slug:"top-3-cap-tien-bien-dong",title:"Top 3 cặp tiền tệ biến động mạnh nhất tuần qua",excerpt:"GBP/JPY, EUR/USD và USD/CHF là những cặp tiền có biên độ dao động lớn nhất.",published_at:"2026-01-25",category:"Phân Tích",featured_image:"https://sanuytin.net/wp-content/uploads/2025/11/forex-market-news.jpg"}];return d?(0,e.jsx)("section",{id:"blog",className:"py-16 bg-slate-50 dark:bg-slate-950/50",children:(0,e.jsxs)("div",{className:"container-custom",children:[(0,e.jsx)("div",{className:"flex flex-col md:flex-row justify-between items-end mb-8 gap-3",children:(0,e.jsxs)("div",{children:[(0,e.jsx)("h2",{className:"text-xl md:text-3xl font-bold text-slate-900 dark:text-white mb-2",children:"Tin Tức Mới Nhất"}),(0,e.jsx)("p",{className:"text-muted-foreground",children:"Cập nhật thị trường Forex, vàng, tiền điện tử mới nhất."})]})}),(0,e.jsx)("div",{className:"grid md:grid-cols-3 gap-6",children:[1,2,3].map(t=>(0,e.jsxs)("div",{className:"bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-slate-800 animate-pulse",children:[(0,e.jsx)("div",{className:"aspect-video bg-slate-200 dark:bg-slate-800"}),(0,e.jsxs)("div",{className:"p-4 space-y-3",children:[(0,e.jsx)("div",{className:"h-4 bg-slate-200 dark:bg-slate-700 rounded w-1/3"}),(0,e.jsx)("div",{className:"h-6 bg-slate-200 dark:bg-slate-700 rounded"}),(0,e.jsx)("div",{className:"h-4 bg-slate-200 dark:bg-slate-700 rounded w-2/3"})]})]},t))})]})}):(0,e.jsx)("section",{id:"blog",className:"py-16 bg-slate-50 dark:bg-slate-950/50",children:(0,e.jsxs)("div",{className:"container-custom",children:[(0,e.jsxs)("div",{className:"flex flex-col md:flex-row justify-between items-end mb-8 gap-3",children:[(0,e.jsxs)("div",{className:"flex items-center gap-4",children:[(0,e.jsx)("div",{className:"p-3 bg-primary/10 rounded-xl text-primary",children:(0,e.jsx)(r.Newspaper,{size:28})}),(0,e.jsxs)("div",{children:[(0,e.jsx)("h2",{className:"text-xl md:text-3xl font-bold text-slate-900 dark:text-white mb-1",children:"Tin Tức Mới Nhất"}),(0,e.jsx)("p",{className:"text-muted-foreground",children:"Cập nhật thị trường Forex, vàng, tiền điện tử."})]})]}),(0,e.jsxs)(n.default,{href:"/tin-tuc",className:"text-primary dark:text-blue-400 font-bold hover:underline flex items-center gap-1",children:["Xem tất cả tin tức ",(0,e.jsx)(s.ArrowRight,{size:18})]})]}),(0,e.jsx)("div",{className:"grid md:grid-cols-3 gap-6",children:g.map(t=>{var r;return(0,e.jsxs)("article",{className:"bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-slate-100 dark:border-slate-800 flex flex-col h-full group",children:[(0,e.jsx)(n.default,{href:`/tin-tuc/${t.slug}`,children:(0,e.jsxs)("div",{className:"aspect-video relative overflow-hidden bg-slate-200 dark:bg-slate-800",children:[(0,e.jsx)("img",{src:t.featured_image||"https://placehold.co/600x400/1e293b/ffffff?text=News",alt:t.title,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-500",onError:t=>{t.currentTarget.src="https://placehold.co/600x400/1e293b/ffffff?text=News"}}),(0,e.jsxs)("div",{className:"absolute top-4 left-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur text-xs font-bold px-3 py-1 rounded-full text-slate-800 dark:text-slate-200 flex items-center gap-1",children:[(0,e.jsx)(a.Bookmark,{size:12,className:"text-primary dark:text-blue-400 fill-current"}),t.category||"Tin tức"]})]})}),(0,e.jsxs)("div",{className:"p-4 flex-1 flex flex-col",children:[(0,e.jsxs)("div",{className:"flex items-center gap-2 text-xs text-muted-foreground mb-3",children:[(0,e.jsx)(i.Calendar,{size:14}),(r=t.published_at)?new Date(r).toLocaleDateString("vi-VN",{day:"2-digit",month:"2-digit",year:"numeric"}):""]}),(0,e.jsx)("h3",{className:"font-bold text-lg text-slate-900 dark:text-white mb-2 line-clamp-2 hover:text-primary dark:hover:text-blue-400 transition-colors",children:(0,e.jsx)(n.default,{href:`/tin-tuc/${t.slug}`,children:t.title})}),(0,e.jsx)("p",{className:"text-muted-foreground text-sm line-clamp-3 mb-4 flex-1",children:t.excerpt}),(0,e.jsxs)(n.default,{href:`/tin-tuc/${t.slug}`,className:"inline-flex items-center text-primary dark:text-blue-400 font-semibold text-sm hover:gap-2 transition-all",children:["Đọc tiếp ",(0,e.jsx)(s.ArrowRight,{size:16,className:"ml-1"})]})]})]},t.id)})})]})})}t.s(["default",()=>c])},28792,t=>{"use strict";var e=t.i(43476),n=t.i(71645),s=t.i(7233),i=t.i(99023),a=t.i(75157);function r(){return(0,e.jsx)("section",{className:"py-16 bg-background relative z-10",children:(0,e.jsxs)("div",{className:"container-custom max-w-4xl",children:[(0,e.jsxs)("div",{className:"text-center mb-10",children:[(0,e.jsx)("h2",{className:"text-2xl md:text-4xl font-bold text-foreground",children:"Câu Hỏi Thường Gặp"}),(0,e.jsx)("p",{className:"text-muted-foreground mt-3 text-base",children:"Giải đáp thắc mắc cho nhà đầu tư mới."})]}),(0,e.jsx)("div",{className:"space-y-3",children:[{question:"Forex là gì?",answer:"Forex, hay còn gọi là thị trường ngoại hối, là thị trường tài chính toàn cầu nơi diễn ra các hoạt động mua bán cặp tiền tệ quốc tế. Forex là thị trường tài chính lớn nhất và có tính thanh khoản cao nhất trên thế giới."},{question:"Làm thế nào để bắt đầu giao dịch Forex ?",answer:"Để bắt đầu giao dịch Forex, bạn cần chọn một sàn giao dịch uy tín, mở tài khoản giao dịch, nạp tiền và làm quen với nền tảng giao dịch. Một cách tốt để bắt đầu là sử dụng tài khoản demo để thực hành mà không có rủi ro vốn."},{question:"Các cặp tiền tệ nào là phổ biến nhất ?",answer:"Các cặp tiền tệ phổ biến nhất bao gồm EUR/USD, GBP/USD, USD/JPY, USD/CHF. Đây là những cặp tiền tệ có tính thanh khoản cao nhất và thường có spread thấp, rất phù hợp cho các nhà giao dịch mới."},{question:"Spread và hoa hồng là gì ?",answer:"Spread là chênh lệch giữa giá mua và giá bán của một cặp tiền tệ, còn hoa hồng là khoản phí mà sàn giao dịch thu từ mỗi giao dịch. Spread và hoa hồng thấp giúp giảm chi phí giao dịch và tối đa hoá lợi nhuận của bạn."},{question:"Đòn bẩy là gì ?",answer:"Đòn bẩy là công cụ tài chính cho phép bạn giao dịch với số vốn lớn hơn số vốn bạn có sẵn trong tài khoản. Ví dụ, với đòn bẩy 1:100, bạn có thể mở lệnh giao dịch trị giá $10.000 chỉ với $100 trong tài khoản."},{question:"Tôi có thể giao dịch Forex ở đâu ?",answer:"Forex là thị trường toàn cầu, hoạt động 24 giờ mỗi ngày từ thứ Hai đến thứ Sáu. Bạn có thể giao dịch từ bất kỳ đâu có kết nối Internet, chỉ cần truy cập vào nền tảng giao dịch của sàn bạn chọn."},{question:"Giao dịch Forex có gì rủi ro ?",answer:"Giao dịch Forex đi kèm với nhiều rủi ro như biến động giá mạnh, đòn bẩy cao có thể tạo ra lỗ lớn, rủi ro từ sàn giao dịch không uy tín. Do đó, quản lý rủi ro và chọn sàn giao dịch uy tín là rất quan trọng."},{question:"Phân tích kỹ thuật có cần thiết không ?",answer:"Có, phân tích kỹ thuật là công cụ quan trọng giúp dự đoán xu hướng giá và quyết định thời điểm ra vào giao dịch."},{question:"Làm sao để giảm thiểu thua lỗ khi giao dịch?",answer:"Sử dụng lệnh Stop lost (dừng lỗ), không đặt cược quá nhiều vào một giao dịch và luôn tuân thủ kế hoạch giao dịch."},{question:"Làm thế nào để chọn sàn giao dịch Forex uy tín ?",answer:"Chọn sàn giao dịch có giấy phép từ các cơ quan quản lý tài chính uy tín, có dịch vụ hỗ trợ khách hàng tốt, nền tảng giao dịch mạnh mẽ và điều kiện giao dịch minh bạch như spread thấp, không có phí ẩn."}].map((t,n)=>(0,e.jsx)(h,{question:t.question,answer:t.answer},n))})]})})}function h({question:t,answer:r}){let[h,o]=(0,n.useState)(!1);return(0,e.jsxs)("div",{className:(0,a.cn)("border rounded-lg overflow-hidden transition-all duration-300",h?"border-primary/50 bg-secondary/30 shadow-md":"border-border/60 bg-card hover:border-primary/30"),children:[(0,e.jsxs)("button",{onClick:()=>o(!h),className:"w-full flex items-center justify-between p-4 text-left transition-colors select-none","aria-expanded":h,children:[(0,e.jsx)("span",{className:(0,a.cn)("font-bold text-base pr-4 transition-colors",h?"text-primary":"text-foreground"),children:t}),(0,e.jsx)("span",{className:(0,a.cn)("p-1.5 rounded-full transition-all duration-300 shrink-0",h?"bg-primary text-white rotate-180":"bg-secondary text-muted-foreground"),children:h?(0,e.jsx)(i.Minus,{size:18}):(0,e.jsx)(s.Plus,{size:18})})]}),(0,e.jsx)("div",{className:(0,a.cn)("grid transition-[grid-template-rows] duration-300 ease-out",h?"grid-rows-[1fr]":"grid-rows-[0fr]"),children:(0,e.jsx)("div",{className:"overflow-hidden",children:(0,e.jsx)("div",{className:"p-4 pt-0 text-muted-foreground leading-relaxed border-t border-dashed border-border/50 pt-3 text-sm",children:r})})})]})}t.s(["default",()=>r])}]);